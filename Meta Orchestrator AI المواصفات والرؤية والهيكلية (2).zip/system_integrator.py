import subprocess
import os

class SystemIntegrator:
    def __init__(self, project_root):
        self.project_root = project_root

    def run_command(self, command, cwd=None):
        if cwd is None:
            cwd = self.project_root
        try:
            result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=True)
            print(f"Command executed successfully: {command}")
            print(f"STDOUT:\n{result.stdout}")
            return result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command failed: {command}")
            print(f"STDERR:\n{e.stderr}")
            raise e

    def run_static_analysis(self, language, file_path):
        print(f"Running static analysis for {file_path} ({language})...")
        if language == "Python":
            self.run_command(["flake8", file_path])
            self.run_command(["mypy", file_path])
            self.run_command(["black", file_path])
        elif language == "JavaScript":
            # Placeholder for JS tools, as they are not installed via pip
            print("JS static analysis tools (eslint, prettier) are not installed via pip. Skipping.")
        else:
            print(f"Static analysis not supported for language: {language}")

    def run_unit_tests(self, language, test_file_path):
        print(f"Running unit tests for {test_file_path} ({language})...")
        if language == "Python":
            self.run_command(["pytest", test_file_path])
        elif language == "JavaScript":
            # Placeholder for JS tools
            print("JS test runner (Jest) is not installed. Skipping.")
        else:
            print(f"Unit testing not supported for language: {language}")

    # Placeholder for Git operations, build, deploy, etc.
    def git_add(self, file_path):
        self.run_command(["git", "add", file_path])

    def git_commit(self, message):
        self.run_command(["git", "commit", "-m", message])



