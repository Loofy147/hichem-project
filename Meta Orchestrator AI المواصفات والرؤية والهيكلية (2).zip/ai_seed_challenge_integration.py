import os
import json
import sqlite3
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from ai_seed import AISeed, TaskType, Experience, LearningPhase, LearningStrategy
from challenges_and_reports import (
    ChallengeManager, Challenge, ChallengeAttempt, 
    DifficultyLevel, ChallengeType, ChallengeStatus
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class AISeedChallengeSession:
    """جلسة تدريب بذرة الذكاء الاصطناعي على التحديات"""
    session_id: str
    seed_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    challenges_attempted: int = 0
    challenges_completed: int = 0
    total_score: float = 0.0
    learning_progress: Dict[str, Any] = None
    session_notes: str = ""

@dataclass
class LearningMetrics:
    """مقاييس التعلم للبذرة"""
    session_id: str
    timestamp: datetime
    learning_phase: str
    strategy_used: str
    challenge_type: str
    difficulty_level: str
    time_taken: float
    score_achieved: float
    improvement_rate: float
    pattern_discovery: bool
    knowledge_transfer: bool

class AISeedTrainer:
    """مدرب بذرة الذكاء الاصطناعي على التحديات"""
    
    def __init__(self, orchestrator=None):
        self.orchestrator = orchestrator
        self.challenge_manager = ChallengeManager()
        self.active_seeds = {}  # seed_id -> AISeed
        self.training_sessions = {}  # session_id -> AISeedChallengeSession
        self.learning_metrics = []
        
        # إعدادات التدريب
        self.training_config = {
            "max_concurrent_seeds": 5,
            "session_duration_minutes": 60,
            "challenges_per_session": 10,
            "difficulty_progression": True,
            "adaptive_difficulty": True,
            "cross_seed_learning": True
        }
        
        # قاعدة بيانات التدريب
        self.training_db_path = "ai_seed_training.db"
        self.init_training_database()
        
        # خيط المراقبة
        self.monitoring_active = False
        self.monitoring_thread = None
        
        logger.info("تم تهيئة مدرب بذرة الذكاء الاصطناعي")
    
    def init_training_database(self):
        """تهيئة قاعدة بيانات التدريب"""
        with sqlite3.connect(self.training_db_path) as conn:
            # جدول جلسات التدريب
            conn.execute("""
                CREATE TABLE IF NOT EXISTS training_sessions (
                    session_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    start_time TEXT NOT NULL,
                    end_time TEXT,
                    challenges_attempted INTEGER DEFAULT 0,
                    challenges_completed INTEGER DEFAULT 0,
                    total_score REAL DEFAULT 0.0,
                    learning_progress TEXT,
                    session_notes TEXT
                )
            """)
            
            # جدول مقاييس التعلم
            conn.execute("""
                CREATE TABLE IF NOT EXISTS learning_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    learning_phase TEXT NOT NULL,
                    strategy_used TEXT NOT NULL,
                    challenge_type TEXT NOT NULL,
                    difficulty_level TEXT NOT NULL,
                    time_taken REAL NOT NULL,
                    score_achieved REAL NOT NULL,
                    improvement_rate REAL NOT NULL,
                    pattern_discovery BOOLEAN DEFAULT FALSE,
                    knowledge_transfer BOOLEAN DEFAULT FALSE
                )
            """)
            
            # جدول تقدم البذور
            conn.execute("""
                CREATE TABLE IF NOT EXISTS seed_progress (
                    seed_id TEXT PRIMARY KEY,
                    total_sessions INTEGER DEFAULT 0,
                    total_challenges INTEGER DEFAULT 0,
                    average_score REAL DEFAULT 0.0,
                    current_level TEXT DEFAULT 'beginner',
                    specializations TEXT,
                    last_training TEXT,
                    performance_trend TEXT
                )
            """)
    
    def create_seed(self, seed_id: str = None, config: Dict[str, Any] = None) -> AISeed:
        """إنشاء بذرة ذكاء اصطناعي جديدة"""
        if seed_id is None:
            seed_id = f"seed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # إنشاء البذرة
        seed = AISeed(seed_id=seed_id, orchestrator=self.orchestrator)
        
        # تطبيق الإعدادات المخصصة
        if config:
            if "exploration_rate" in config:
                seed.brain.exploration_rate = config["exploration_rate"]
            if "confidence_threshold" in config:
                seed.brain.confidence_threshold = config["confidence_threshold"]
            if "learning_rate" in config:
                seed.brain.learning_rate = config["learning_rate"]
        
        # بدء التعلم
        seed.start_learning()
        
        # إضافة للبذور النشطة
        self.active_seeds[seed_id] = seed
        
        # تسجيل في قاعدة البيانات
        self.register_seed_progress(seed_id)
        
        logger.info(f"تم إنشاء بذرة جديدة: {seed_id}")
        return seed
    
    def register_seed_progress(self, seed_id: str):
        """تسجيل تقدم البذرة في قاعدة البيانات"""
        with sqlite3.connect(self.training_db_path) as conn:
            conn.execute("""
                INSERT OR IGNORE INTO seed_progress 
                (seed_id, last_training, specializations, performance_trend)
                VALUES (?, ?, ?, ?)
            """, (
                seed_id,
                datetime.now().isoformat(),
                json.dumps([]),
                json.dumps([])
            ))
    
    def start_training_session(self, seed_id: str, session_config: Dict[str, Any] = None) -> str:
        """بدء جلسة تدريب للبذرة"""
        if seed_id not in self.active_seeds:
            raise ValueError(f"البذرة {seed_id} غير موجودة")
        
        # إنشاء معرف الجلسة
        session_id = f"session_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # إعداد الجلسة
        session = AISeedChallengeSession(
            session_id=session_id,
            seed_id=seed_id,
            start_time=datetime.now(),
            learning_progress={}
        )
        
        # حفظ الجلسة
        self.training_sessions[session_id] = session
        self.save_training_session(session)
        
        # بدء التدريب في خيط منفصل
        training_thread = threading.Thread(
            target=self._run_training_session,
            args=(session_id, session_config or {}),
            daemon=True
        )
        training_thread.start()
        
        logger.info(f"تم بدء جلسة تدريب: {session_id}")
        return session_id
    
    def _run_training_session(self, session_id: str, config: Dict[str, Any]):
        """تشغيل جلسة التدريب"""
        try:
            session = self.training_sessions[session_id]
            seed = self.active_seeds[session.seed_id]
            
            # إعدادات الجلسة
            max_challenges = config.get("challenges_per_session", self.training_config["challenges_per_session"])
            session_duration = config.get("session_duration_minutes", self.training_config["session_duration_minutes"])
            
            start_time = datetime.now()
            end_time = start_time + timedelta(minutes=session_duration)
            
            challenges_completed = 0
            
            while datetime.now() < end_time and challenges_completed < max_challenges:
                try:
                    # اختيار التحدي المناسب
                    challenge = self.select_appropriate_challenge(seed)
                    
                    if challenge:
                        # تنفيذ التحدي
                        result = self.execute_challenge_with_seed(seed, challenge, session_id)
                        
                        # تحديث الجلسة
                        session.challenges_attempted += 1
                        if result.get("success", False):
                            session.challenges_completed += 1
                            challenges_completed += 1
                        
                        session.total_score += result.get("score", 0.0)
                        
                        # حفظ مقاييس التعلم
                        self.record_learning_metrics(session_id, seed, challenge, result)
                        
                        # انتظار قصير بين التحديات
                        time.sleep(2)
                    
                    else:
                        # لا توجد تحديات مناسبة، انتظار أطول
                        time.sleep(10)
                
                except Exception as e:
                    logger.error(f"خطأ في تنفيذ التحدي: {e}")
                    time.sleep(5)
            
            # إنهاء الجلسة
            session.end_time = datetime.now()
            self.save_training_session(session)
            
            # تحديث تقدم البذرة
            self.update_seed_progress(session.seed_id, session)
            
            logger.info(f"انتهت جلسة التدريب: {session_id}")
            
        except Exception as e:
            logger.error(f"خطأ في جلسة التدريب {session_id}: {e}")
    
    def select_appropriate_challenge(self, seed: AISeed) -> Optional[Challenge]:
        """اختيار التحدي المناسب للبذرة"""
        try:
            # تحديد مستوى الصعوبة المناسب
            difficulty = self.determine_appropriate_difficulty(seed)
            
            # تحديد نوع التحدي بناءً على التخصص
            challenge_type = self.determine_challenge_type(seed)
            
            # إنشاء تحدي جديد
            challenge = self.challenge_manager.create_challenge(
                difficulty=difficulty,
                challenge_type=challenge_type
            )
            
            return challenge
            
        except Exception as e:
            logger.error(f"خطأ في اختيار التحدي: {e}")
            return None
    
    def determine_appropriate_difficulty(self, seed: AISeed) -> DifficultyLevel:
        """تحديد مستوى الصعوبة المناسب للبذرة"""
        # تحليل أداء البذرة
        avg_score = seed.performance_metrics.get("average_score", 0.0)
        learning_phase = seed.brain.learning_phase
        
        if learning_phase == LearningPhase.INITIALIZATION:
            return DifficultyLevel.BEGINNER
        elif learning_phase == LearningPhase.EXPLORATION:
            return DifficultyLevel.BEGINNER if avg_score < 0.5 else DifficultyLevel.INTERMEDIATE
        elif learning_phase == LearningPhase.EXPLOITATION:
            return DifficultyLevel.INTERMEDIATE if avg_score < 0.7 else DifficultyLevel.ADVANCED
        elif learning_phase == LearningPhase.REFINEMENT:
            return DifficultyLevel.ADVANCED
        else:  # MASTERY
            return DifficultyLevel.EXPERT
    
    def determine_challenge_type(self, seed: AISeed) -> ChallengeType:
        """تحديد نوع التحدي بناءً على تخصص البذرة"""
        # تحليل أنماط البذرة لتحديد التخصص
        patterns = seed.brain.patterns
        
        if not patterns:
            # اختيار عشوائي للبذور الجديدة
            return random.choice(list(ChallengeType))
        
        # تحليل أنواع المهام الأكثر نجاحاً
        task_type_scores = {}
        for pattern in patterns.values():
            pattern_type = pattern.pattern_type
            if pattern_type not in task_type_scores:
                task_type_scores[pattern_type] = []
            task_type_scores[pattern_type].append(pattern.success_rate)
        
        # اختيار النوع الأفضل أو تنويع التدريب
        if random.random() < 0.7:  # 70% اختيار التخصص الأفضل
            best_type = max(task_type_scores.items(), 
                          key=lambda x: sum(x[1])/len(x[1]) if x[1] else 0)
            
            # تحويل نوع المهمة إلى نوع التحدي
            return self.map_task_type_to_challenge_type(best_type[0])
        else:  # 30% تنويع التدريب
            return random.choice(list(ChallengeType))
    
    def map_task_type_to_challenge_type(self, task_type: str) -> ChallengeType:
        """تحويل نوع المهمة إلى نوع التحدي"""
        mapping = {
            "code_generation": ChallengeType.ALGORITHM,
            "code_review": ChallengeType.DEBUGGING,
            "debugging": ChallengeType.DEBUGGING,
            "optimization": ChallengeType.OPTIMIZATION,
            "testing": ChallengeType.TESTING,
            "documentation": ChallengeType.API_DEVELOPMENT
        }
        
        for key, value in mapping.items():
            if key in task_type:
                return value
        
        return ChallengeType.ALGORITHM  # افتراضي
    
    def execute_challenge_with_seed(self, seed: AISeed, challenge: Challenge, session_id: str) -> Dict[str, Any]:
        """تنفيذ التحدي مع البذرة"""
        try:
            start_time = datetime.now()
            
            # تحويل التحدي إلى مهمة للبذرة
            task_data = self.convert_challenge_to_task(challenge)
            
            # معالجة المهمة بواسطة البذرة
            result = seed.process_task(task_data)
            
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # تقييم النتيجة
            evaluation = self.evaluate_challenge_result(challenge, result)
            
            # إنشاء محاولة في نظام التحديات
            attempt = self.challenge_manager.submit_solution(
                challenge_id=challenge.id,
                user_id=seed.seed_id,
                submitted_files={"solution.py": result.get("result", {}).get("code", "")},
                execution_time=execution_time
            )
            
            return {
                "success": evaluation["success"],
                "score": evaluation["score"],
                "execution_time": execution_time,
                "attempt_id": attempt.id,
                "feedback": evaluation["feedback"],
                "learning_insights": evaluation.get("learning_insights", {})
            }
            
        except Exception as e:
            logger.error(f"خطأ في تنفيذ التحدي: {e}")
            return {
                "success": False,
                "score": 0.0,
                "execution_time": 0.0,
                "error": str(e)
            }
    
    def convert_challenge_to_task(self, challenge: Challenge) -> Dict[str, Any]:
        """تحويل التحدي إلى مهمة للبذرة"""
        # تحديد نوع المهمة بناءً على نوع التحدي
        task_type_mapping = {
            ChallengeType.ALGORITHM: "code_generation",
            ChallengeType.DATA_STRUCTURE: "code_generation",
            ChallengeType.WEB_DEVELOPMENT: "code_generation",
            ChallengeType.MACHINE_LEARNING: "code_generation",
            ChallengeType.DEBUGGING: "debugging",
            ChallengeType.OPTIMIZATION: "optimization",
            ChallengeType.TESTING: "testing",
            ChallengeType.API_DEVELOPMENT: "code_generation",
            ChallengeType.DATABASE: "code_generation",
            ChallengeType.SYSTEM_DESIGN: "code_generation"
        }
        
        task_type = task_type_mapping.get(challenge.challenge_type, "code_generation")
        
        return {
            "type": task_type,
            "description": challenge.description,
            "requirements": challenge.requirements,
            "language": challenge.language,
            "difficulty": challenge.difficulty.value,
            "challenge_id": challenge.id,
            "test_cases": challenge.test_cases,
            "constraints": challenge.constraints
        }
    
    def evaluate_challenge_result(self, challenge: Challenge, result: Dict[str, Any]) -> Dict[str, Any]:
        """تقييم نتيجة التحدي"""
        try:
            # التقييم الأساسي من البذرة
            base_score = result.get("confidence", 0.0)
            
            # تقييم إضافي بناءً على التحدي
            additional_score = 0.0
            feedback = []
            learning_insights = {}
            
            # فحص وجود الحل
            solution = result.get("result", {})
            if solution and "code" in solution:
                additional_score += 0.3
                feedback.append("تم توليد حل للتحدي")
                
                # فحص جودة الكود
                code = solution["code"]
                if len(code) > 50:  # حل مفصل
                    additional_score += 0.2
                    feedback.append("الحل مفصل ومناسب")
                
                # فحص التعليقات
                if "#" in code or '"""' in code:
                    additional_score += 0.1
                    feedback.append("الكود موثق بتعليقات")
                
                # فحص الهيكل
                if "def " in code:
                    additional_score += 0.2
                    feedback.append("الحل منظم في دوال")
                
                # تحليل التعقيد
                lines = code.split("\n")
                complexity_score = min(len(lines) / 20.0, 0.2)
                additional_score += complexity_score
                
                learning_insights["code_complexity"] = len(lines)
                learning_insights["has_functions"] = "def " in code
                learning_insights["has_comments"] = "#" in code or '"""' in code
            
            # حساب النتيجة النهائية
            final_score = min((base_score + additional_score) / 2.0, 1.0)
            
            # تحديد النجاح
            success = final_score > 0.5
            
            return {
                "success": success,
                "score": final_score,
                "feedback": "; ".join(feedback),
                "learning_insights": learning_insights,
                "base_score": base_score,
                "additional_score": additional_score
            }
            
        except Exception as e:
            logger.error(f"خطأ في تقييم النتيجة: {e}")
            return {
                "success": False,
                "score": 0.0,
                "feedback": f"خطأ في التقييم: {e}",
                "learning_insights": {}
            }
    
    def record_learning_metrics(self, session_id: str, seed: AISeed, challenge: Challenge, result: Dict[str, Any]):
        """تسجيل مقاييس التعلم"""
        try:
            # حساب معدل التحسن
            recent_scores = [exp.feedback_score for exp in seed.brain.experiences[-5:]]
            improvement_rate = 0.0
            if len(recent_scores) > 1:
                improvement_rate = recent_scores[-1] - recent_scores[0]
            
            # إنشاء مقياس التعلم
            metric = LearningMetrics(
                session_id=session_id,
                timestamp=datetime.now(),
                learning_phase=seed.brain.learning_phase.value,
                strategy_used=seed.brain.current_strategy.value,
                challenge_type=challenge.challenge_type.value,
                difficulty_level=challenge.difficulty.value,
                time_taken=result.get("execution_time", 0.0),
                score_achieved=result.get("score", 0.0),
                improvement_rate=improvement_rate,
                pattern_discovery=len(seed.brain.patterns) > len(self.get_previous_patterns_count(seed.seed_id)),
                knowledge_transfer=seed.brain.current_strategy == LearningStrategy.TRANSFER
            )
            
            # حفظ في قاعدة البيانات
            self.save_learning_metric(metric)
            self.learning_metrics.append(metric)
            
        except Exception as e:
            logger.error(f"خطأ في تسجيل مقاييس التعلم: {e}")
    
    def get_previous_patterns_count(self, seed_id: str) -> int:
        """الحصول على عدد الأنماط السابق للبذرة"""
        # يمكن تحسين هذا بحفظ العدد في قاعدة البيانات
        return 0
    
    def save_learning_metric(self, metric: LearningMetrics):
        """حفظ مقياس التعلم في قاعدة البيانات"""
        with sqlite3.connect(self.training_db_path) as conn:
            conn.execute("""
                INSERT INTO learning_metrics 
                (session_id, timestamp, learning_phase, strategy_used, challenge_type,
                 difficulty_level, time_taken, score_achieved, improvement_rate,
                 pattern_discovery, knowledge_transfer)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                metric.session_id,
                metric.timestamp.isoformat(),
                metric.learning_phase,
                metric.strategy_used,
                metric.challenge_type,
                metric.difficulty_level,
                metric.time_taken,
                metric.score_achieved,
                metric.improvement_rate,
                metric.pattern_discovery,
                metric.knowledge_transfer
            ))
    
    def save_training_session(self, session: AISeedChallengeSession):
        """حفظ جلسة التدريب في قاعدة البيانات"""
        with sqlite3.connect(self.training_db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO training_sessions 
                (session_id, seed_id, start_time, end_time, challenges_attempted,
                 challenges_completed, total_score, learning_progress, session_notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session.session_id,
                session.seed_id,
                session.start_time.isoformat(),
                session.end_time.isoformat() if session.end_time else None,
                session.challenges_attempted,
                session.challenges_completed,
                session.total_score,
                json.dumps(session.learning_progress or {}),
                session.session_notes
            ))
    
    def update_seed_progress(self, seed_id: str, session: AISeedChallengeSession):
        """تحديث تقدم البذرة"""
        try:
            with sqlite3.connect(self.training_db_path) as conn:
                # الحصول على التقدم الحالي
                cursor = conn.execute(
                    "SELECT total_sessions, total_challenges, average_score FROM seed_progress WHERE seed_id = ?",
                    (seed_id,)
                )
                row = cursor.fetchone()
                
                if row:
                    total_sessions, total_challenges, avg_score = row
                    
                    # تحديث الإحصائيات
                    new_total_sessions = total_sessions + 1
                    new_total_challenges = total_challenges + session.challenges_attempted
                    
                    # حساب المتوسط الجديد
                    if session.challenges_attempted > 0:
                        session_avg = session.total_score / session.challenges_attempted
                        new_avg_score = (avg_score * total_challenges + session.total_score) / new_total_challenges
                    else:
                        new_avg_score = avg_score
                    
                    # تحديد المستوى الحالي
                    current_level = self.determine_seed_level(new_avg_score, new_total_challenges)
                    
                    # تحديث قاعدة البيانات
                    conn.execute("""
                        UPDATE seed_progress 
                        SET total_sessions = ?, total_challenges = ?, average_score = ?,
                            current_level = ?, last_training = ?
                        WHERE seed_id = ?
                    """, (
                        new_total_sessions,
                        new_total_challenges,
                        new_avg_score,
                        current_level,
                        datetime.now().isoformat(),
                        seed_id
                    ))
                    
                    logger.info(f"تم تحديث تقدم البذرة {seed_id}: المستوى {current_level}")
                
        except Exception as e:
            logger.error(f"خطأ في تحديث تقدم البذرة: {e}")
    
    def determine_seed_level(self, avg_score: float, total_challenges: int) -> str:
        """تحديد مستوى البذرة"""
        if total_challenges < 10:
            return "novice"
        elif avg_score < 0.4:
            return "beginner"
        elif avg_score < 0.6:
            return "intermediate"
        elif avg_score < 0.8:
            return "advanced"
        else:
            return "expert"
    
    def start_monitoring(self):
        """بدء مراقبة البذور النشطة"""
        if self.monitoring_active:
            return
        
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitor_seeds, daemon=True)
        self.monitoring_thread.start()
        logger.info("تم بدء مراقبة البذور")
    
    def stop_monitoring(self):
        """إيقاف مراقبة البذور"""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join()
        logger.info("تم إيقاف مراقبة البذور")
    
    def _monitor_seeds(self):
        """مراقبة البذور النشطة"""
        while self.monitoring_active:
            try:
                for seed_id, seed in self.active_seeds.items():
                    # فحص حالة البذرة
                    status = seed.get_status()
                    
                    # تحليل الأداء
                    if status["total_experiences"] > 0:
                        self.analyze_seed_performance(seed_id, status)
                    
                    # تحديد ما إذا كانت البذرة تحتاج لتدريب إضافي
                    if self.needs_additional_training(seed_id, status):
                        self.schedule_training_session(seed_id)
                
                # انتظار قبل الدورة التالية
                time.sleep(300)  # 5 دقائق
                
            except Exception as e:
                logger.error(f"خطأ في مراقبة البذور: {e}")
                time.sleep(60)
    
    def analyze_seed_performance(self, seed_id: str, status: Dict[str, Any]):
        """تحليل أداء البذرة"""
        try:
            # تحليل الاتجاهات
            performance_metrics = status.get("performance_metrics", {})
            avg_score = performance_metrics.get("average_score", 0.0)
            improvement_rate = performance_metrics.get("improvement_rate", 0.0)
            
            # تسجيل التحليل
            analysis = {
                "timestamp": datetime.now().isoformat(),
                "seed_id": seed_id,
                "average_score": avg_score,
                "improvement_rate": improvement_rate,
                "learning_phase": status.get("learning_phase", "unknown"),
                "patterns_count": status.get("patterns_count", 0)
            }
            
            # حفظ التحليل (يمكن إضافة جدول منفصل للتحليلات)
            logger.info(f"تحليل أداء البذرة {seed_id}: {analysis}")
            
        except Exception as e:
            logger.error(f"خطأ في تحليل أداء البذرة: {e}")
    
    def needs_additional_training(self, seed_id: str, status: Dict[str, Any]) -> bool:
        """تحديد ما إذا كانت البذرة تحتاج تدريب إضافي"""
        try:
            # معايير الحاجة للتدريب
            avg_score = status.get("performance_metrics", {}).get("average_score", 0.0)
            improvement_rate = status.get("performance_metrics", {}).get("improvement_rate", 0.0)
            total_experiences = status.get("total_experiences", 0)
            
            # البذور الجديدة تحتاج تدريب
            if total_experiences < 20:
                return True
            
            # البذور ذات الأداء المنخفض
            if avg_score < 0.5:
                return True
            
            # البذور التي توقف تحسنها
            if improvement_rate < -0.1:
                return True
            
            # فحص آخر جلسة تدريب
            last_session = self.get_last_training_session(seed_id)
            if last_session:
                time_since_last = datetime.now() - datetime.fromisoformat(last_session["start_time"])
                if time_since_last > timedelta(hours=24):  # لم تتدرب لأكثر من 24 ساعة
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"خطأ في تحديد الحاجة للتدريب: {e}")
            return False
    
    def get_last_training_session(self, seed_id: str) -> Optional[Dict[str, Any]]:
        """الحصول على آخر جلسة تدريب للبذرة"""
        try:
            with sqlite3.connect(self.training_db_path) as conn:
                cursor = conn.execute("""
                    SELECT * FROM training_sessions 
                    WHERE seed_id = ? 
                    ORDER BY start_time DESC 
                    LIMIT 1
                """, (seed_id,))
                
                row = cursor.fetchone()
                if row:
                    columns = [desc[0] for desc in cursor.description]
                    return dict(zip(columns, row))
                
                return None
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على آخر جلسة تدريب: {e}")
            return None
    
    def schedule_training_session(self, seed_id: str):
        """جدولة جلسة تدريب للبذرة"""
        try:
            # فحص عدد الجلسات النشطة
            active_sessions = len([s for s in self.training_sessions.values() if s.end_time is None])
            
            if active_sessions < self.training_config["max_concurrent_seeds"]:
                session_id = self.start_training_session(seed_id)
                logger.info(f"تم جدولة جلسة تدريب للبذرة {seed_id}: {session_id}")
            else:
                logger.info(f"تأجيل تدريب البذرة {seed_id} - الحد الأقصى للجلسات النشطة")
                
        except Exception as e:
            logger.error(f"خطأ في جدولة التدريب: {e}")
    
    def get_training_statistics(self) -> Dict[str, Any]:
        """الحصول على إحصائيات التدريب"""
        try:
            with sqlite3.connect(self.training_db_path) as conn:
                # إحصائيات عامة
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_sessions,
                        AVG(total_score) as avg_session_score,
                        SUM(challenges_completed) as total_challenges_completed,
                        COUNT(DISTINCT seed_id) as unique_seeds
                    FROM training_sessions
                """)
                general_stats = cursor.fetchone()
                
                # إحصائيات التعلم
                cursor = conn.execute("""
                    SELECT 
                        learning_phase,
                        COUNT(*) as count,
                        AVG(score_achieved) as avg_score
                    FROM learning_metrics
                    GROUP BY learning_phase
                """)
                learning_stats = cursor.fetchall()
                
                # أفضل البذور
                cursor = conn.execute("""
                    SELECT seed_id, average_score, current_level, total_challenges
                    FROM seed_progress
                    ORDER BY average_score DESC
                    LIMIT 5
                """)
                top_seeds = cursor.fetchall()
                
                return {
                    "general": {
                        "total_sessions": general_stats[0],
                        "average_session_score": general_stats[1] or 0.0,
                        "total_challenges_completed": general_stats[2] or 0,
                        "unique_seeds": general_stats[3]
                    },
                    "learning_phases": [
                        {"phase": row[0], "count": row[1], "avg_score": row[2]}
                        for row in learning_stats
                    ],
                    "top_seeds": [
                        {
                            "seed_id": row[0],
                            "average_score": row[1],
                            "level": row[2],
                            "total_challenges": row[3]
                        }
                        for row in top_seeds
                    ],
                    "active_seeds": len(self.active_seeds),
                    "active_sessions": len([s for s in self.training_sessions.values() if s.end_time is None])
                }
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على الإحصائيات: {e}")
            return {}
    
    def export_seed_knowledge(self, seed_id: str) -> Optional[Dict[str, Any]]:
        """تصدير معرفة البذرة"""
        if seed_id in self.active_seeds:
            seed = self.active_seeds[seed_id]
            knowledge = seed.export_knowledge()
            
            # إضافة معلومات التدريب
            training_info = self.get_seed_training_history(seed_id)
            knowledge["training_history"] = training_info
            
            return knowledge
        
        return None
    
    def get_seed_training_history(self, seed_id: str) -> List[Dict[str, Any]]:
        """الحصول على تاريخ تدريب البذرة"""
        try:
            with sqlite3.connect(self.training_db_path) as conn:
                cursor = conn.execute("""
                    SELECT * FROM training_sessions 
                    WHERE seed_id = ? 
                    ORDER BY start_time DESC
                """, (seed_id,))
                
                sessions = []
                for row in cursor.fetchall():
                    columns = [desc[0] for desc in cursor.description]
                    sessions.append(dict(zip(columns, row)))
                
                return sessions
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على تاريخ التدريب: {e}")
            return []
    
    def shutdown(self):
        """إغلاق المدرب وحفظ البيانات"""
        try:
            # إيقاف المراقبة
            self.stop_monitoring()
            
            # إيقاف جميع البذور
            for seed in self.active_seeds.values():
                seed.stop_learning()
            
            # حفظ حالة جميع الجلسات
            for session in self.training_sessions.values():
                if session.end_time is None:
                    session.end_time = datetime.now()
                    self.save_training_session(session)
            
            logger.info("تم إغلاق مدرب البذور بنجاح")
            
        except Exception as e:
            logger.error(f"خطأ في إغلاق المدرب: {e}")

if __name__ == "__main__":
    # مثال على الاستخدام
    trainer = AISeedTrainer()
    
    try:
        # بدء المراقبة
        trainer.start_monitoring()
        
        # إنشاء بذرة جديدة
        seed = trainer.create_seed("test_seed_001")
        
        # بدء جلسة تدريب
        session_id = trainer.start_training_session("test_seed_001")
        
        # انتظار لمدة دقيقة لمشاهدة التدريب
        time.sleep(60)
        
        # عرض الإحصائيات
        stats = trainer.get_training_statistics()
        print(f"إحصائيات التدريب: {json.dumps(stats, indent=2, ensure_ascii=False)}")
        
        # تصدير معرفة البذرة
        knowledge = trainer.export_seed_knowledge("test_seed_001")
        if knowledge:
            print(f"تم تصدير معرفة البذرة: {len(knowledge.get('patterns', []))} نمط")
        
    except KeyboardInterrupt:
        print("إيقاف البرنامج...")
    finally:
        trainer.shutdown()

