import os
import json
import yaml
import subprocess
import time
import psutil
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from pathlib import Path
import logging
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PipelineStage:
    """Represents a single stage in the CI/CD pipeline"""
    name: str
    command: str
    timeout: int = 300
    retry_count: int = 3
    depends_on: List[str] = None
    environment: Dict[str, str] = None
    working_directory: str = None

@dataclass
class PipelineResult:
    """Result of a pipeline execution"""
    stage_name: str
    success: bool
    duration: float
    output: str
    error: str = ""
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

@dataclass
class PerformanceMetrics:
    """Performance metrics for monitoring"""
    timestamp: datetime
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_io: Dict[str, int]
    process_count: int
    load_average: List[float]

class PerformanceMonitor:
    """Monitors system performance metrics"""
    
    def __init__(self, db_path: str = "performance_metrics.db"):
        self.db_path = db_path
        self.monitoring = False
        self.monitor_thread = None
        self.init_database()
    
    def init_database(self):
        """Initialize the performance metrics database"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS performance_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    cpu_usage REAL NOT NULL,
                    memory_usage REAL NOT NULL,
                    disk_usage REAL NOT NULL,
                    network_sent INTEGER NOT NULL,
                    network_recv INTEGER NOT NULL,
                    process_count INTEGER NOT NULL,
                    load_avg_1 REAL,
                    load_avg_5 REAL,
                    load_avg_15 REAL
                )
            """)
    
    def collect_metrics(self) -> PerformanceMetrics:
        """Collect current system performance metrics"""
        try:
            # CPU usage
            cpu_usage = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_usage = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_usage = disk.percent
            
            # Network I/O
            network = psutil.net_io_counters()
            network_io = {
                'bytes_sent': network.bytes_sent,
                'bytes_recv': network.bytes_recv
            }
            
            # Process count
            process_count = len(psutil.pids())
            
            # Load average (Unix-like systems)
            try:
                load_average = list(os.getloadavg())
            except (OSError, AttributeError):
                load_average = [0.0, 0.0, 0.0]
            
            return PerformanceMetrics(
                timestamp=datetime.now(),
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                disk_usage=disk_usage,
                network_io=network_io,
                process_count=process_count,
                load_average=load_average
            )
        except Exception as e:
            logger.error(f"Error collecting performance metrics: {e}")
            return None
    
    def store_metrics(self, metrics: PerformanceMetrics):
        """Store metrics in the database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO performance_metrics 
                    (timestamp, cpu_usage, memory_usage, disk_usage, 
                     network_sent, network_recv, process_count, 
                     load_avg_1, load_avg_5, load_avg_15)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metrics.timestamp.isoformat(),
                    metrics.cpu_usage,
                    metrics.memory_usage,
                    metrics.disk_usage,
                    metrics.network_io['bytes_sent'],
                    metrics.network_io['bytes_recv'],
                    metrics.process_count,
                    metrics.load_average[0],
                    metrics.load_average[1],
                    metrics.load_average[2]
                ))
        except Exception as e:
            logger.error(f"Error storing performance metrics: {e}")
    
    def start_monitoring(self, interval: int = 60):
        """Start continuous performance monitoring"""
        if self.monitoring:
            return
        
        self.monitoring = True
        
        def monitor_loop():
            while self.monitoring:
                metrics = self.collect_metrics()
                if metrics:
                    self.store_metrics(metrics)
                time.sleep(interval)
        
        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()
        logger.info("Performance monitoring started")
    
    def stop_monitoring(self):
        """Stop performance monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
        logger.info("Performance monitoring stopped")
    
    def get_metrics_history(self, hours: int = 24) -> List[Dict]:
        """Get performance metrics history"""
        try:
            since = datetime.now() - timedelta(hours=hours)
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("""
                    SELECT * FROM performance_metrics 
                    WHERE timestamp > ? 
                    ORDER BY timestamp DESC
                """, (since.isoformat(),))
                
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error retrieving metrics history: {e}")
            return []

class CICDPipeline:
    """Automated CI/CD pipeline for code projects"""
    
    def __init__(self, config_path: str = "pipeline_config.yaml"):
        self.config_path = config_path
        self.stages = []
        self.results = []
        self.performance_monitor = PerformanceMonitor()
        self.load_config()
    
    def load_config(self):
        """Load pipeline configuration"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    config = yaml.safe_load(f)
                    self.stages = [
                        PipelineStage(**stage_config) 
                        for stage_config in config.get('stages', [])
                    ]
            else:
                self.create_default_config()
        except Exception as e:
            logger.error(f"Error loading pipeline config: {e}")
            self.create_default_config()
    
    def create_default_config(self):
        """Create default pipeline configuration"""
        default_stages = [
            PipelineStage(
                name="code_analysis",
                command="python -m flake8 . && python -m mypy .",
                timeout=120,
                retry_count=1
            ),
            PipelineStage(
                name="unit_tests",
                command="python -m pytest tests/ -v --cov=. --cov-report=html",
                timeout=300,
                retry_count=2,
                depends_on=["code_analysis"]
            ),
            PipelineStage(
                name="security_scan",
                command="python -m bandit -r . -f json -o security_report.json",
                timeout=180,
                retry_count=1,
                depends_on=["code_analysis"]
            ),
            PipelineStage(
                name="build",
                command="python setup.py build",
                timeout=600,
                retry_count=2,
                depends_on=["unit_tests", "security_scan"]
            ),
            PipelineStage(
                name="integration_tests",
                command="python -m pytest integration_tests/ -v",
                timeout=900,
                retry_count=1,
                depends_on=["build"]
            ),
            PipelineStage(
                name="performance_tests",
                command="python -m pytest performance_tests/ -v --benchmark-only",
                timeout=1200,
                retry_count=1,
                depends_on=["build"]
            ),
            PipelineStage(
                name="deploy_staging",
                command="docker build -t app:staging . && docker run -d --name app-staging app:staging",
                timeout=600,
                retry_count=2,
                depends_on=["integration_tests", "performance_tests"]
            )
        ]
        
        self.stages = default_stages
        self.save_config()
    
    def save_config(self):
        """Save pipeline configuration"""
        try:
            config = {
                'stages': [asdict(stage) for stage in self.stages]
            }
            with open(self.config_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False)
        except Exception as e:
            logger.error(f"Error saving pipeline config: {e}")
    
    def execute_stage(self, stage: PipelineStage, project_path: str) -> PipelineResult:
        """Execute a single pipeline stage"""
        logger.info(f"Executing stage: {stage.name}")
        start_time = time.time()
        
        for attempt in range(stage.retry_count):
            try:
                # Prepare environment
                env = os.environ.copy()
                if stage.environment:
                    env.update(stage.environment)
                
                # Set working directory
                working_dir = stage.working_directory or project_path
                
                # Execute command
                result = subprocess.run(
                    stage.command,
                    shell=True,
                    cwd=working_dir,
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=stage.timeout
                )
                
                duration = time.time() - start_time
                
                if result.returncode == 0:
                    logger.info(f"Stage {stage.name} completed successfully")
                    return PipelineResult(
                        stage_name=stage.name,
                        success=True,
                        duration=duration,
                        output=result.stdout
                    )
                else:
                    logger.warning(f"Stage {stage.name} failed (attempt {attempt + 1})")
                    if attempt == stage.retry_count - 1:
                        return PipelineResult(
                            stage_name=stage.name,
                            success=False,
                            duration=duration,
                            output=result.stdout,
                            error=result.stderr
                        )
            
            except subprocess.TimeoutExpired:
                logger.error(f"Stage {stage.name} timed out (attempt {attempt + 1})")
                if attempt == stage.retry_count - 1:
                    return PipelineResult(
                        stage_name=stage.name,
                        success=False,
                        duration=time.time() - start_time,
                        output="",
                        error="Stage timed out"
                    )
            
            except Exception as e:
                logger.error(f"Error executing stage {stage.name}: {e}")
                if attempt == stage.retry_count - 1:
                    return PipelineResult(
                        stage_name=stage.name,
                        success=False,
                        duration=time.time() - start_time,
                        output="",
                        error=str(e)
                    )
            
            # Wait before retry
            if attempt < stage.retry_count - 1:
                time.sleep(5)
        
        # This should never be reached, but just in case
        return PipelineResult(
            stage_name=stage.name,
            success=False,
            duration=time.time() - start_time,
            output="",
            error="Unknown error"
        )
    
    def check_dependencies(self, stage: PipelineStage) -> bool:
        """Check if stage dependencies are satisfied"""
        if not stage.depends_on:
            return True
        
        completed_stages = {result.stage_name for result in self.results if result.success}
        return all(dep in completed_stages for dep in stage.depends_on)
    
    def run_pipeline(self, project_path: str, parallel: bool = True) -> List[PipelineResult]:
        """Run the complete CI/CD pipeline"""
        logger.info("Starting CI/CD pipeline")
        self.results = []
        
        # Start performance monitoring
        self.performance_monitor.start_monitoring(interval=30)
        
        try:
            if parallel:
                self.run_pipeline_parallel(project_path)
            else:
                self.run_pipeline_sequential(project_path)
        finally:
            # Stop performance monitoring
            self.performance_monitor.stop_monitoring()
        
        # Generate pipeline report
        self.generate_report()
        
        logger.info("CI/CD pipeline completed")
        return self.results
    
    def run_pipeline_sequential(self, project_path: str):
        """Run pipeline stages sequentially"""
        remaining_stages = self.stages.copy()
        
        while remaining_stages:
            executed_any = False
            
            for stage in remaining_stages.copy():
                if self.check_dependencies(stage):
                    result = self.execute_stage(stage, project_path)
                    self.results.append(result)
                    remaining_stages.remove(stage)
                    executed_any = True
                    
                    # Stop pipeline if critical stage fails
                    if not result.success and stage.name in ["code_analysis", "unit_tests"]:
                        logger.error(f"Critical stage {stage.name} failed, stopping pipeline")
                        return
            
            if not executed_any:
                logger.error("Pipeline deadlock: no stages can be executed")
                break
    
    def run_pipeline_parallel(self, project_path: str):
        """Run pipeline stages in parallel where possible"""
        remaining_stages = self.stages.copy()
        
        with ThreadPoolExecutor(max_workers=4) as executor:
            while remaining_stages:
                # Find stages that can be executed
                ready_stages = [
                    stage for stage in remaining_stages 
                    if self.check_dependencies(stage)
                ]
                
                if not ready_stages:
                    logger.error("Pipeline deadlock: no stages can be executed")
                    break
                
                # Submit ready stages for execution
                future_to_stage = {
                    executor.submit(self.execute_stage, stage, project_path): stage
                    for stage in ready_stages
                }
                
                # Wait for completion
                for future in as_completed(future_to_stage):
                    stage = future_to_stage[future]
                    result = future.result()
                    self.results.append(result)
                    remaining_stages.remove(stage)
                    
                    # Stop pipeline if critical stage fails
                    if not result.success and stage.name in ["code_analysis", "unit_tests"]:
                        logger.error(f"Critical stage {stage.name} failed, stopping pipeline")
                        # Cancel remaining futures
                        for f in future_to_stage:
                            f.cancel()
                        return
    
    def generate_report(self):
        """Generate pipeline execution report"""
        try:
            report = {
                "pipeline_execution": {
                    "timestamp": datetime.now().isoformat(),
                    "total_stages": len(self.stages),
                    "executed_stages": len(self.results),
                    "successful_stages": len([r for r in self.results if r.success]),
                    "failed_stages": len([r for r in self.results if not r.success]),
                    "total_duration": sum(r.duration for r in self.results)
                },
                "stage_results": [
                    {
                        "name": result.stage_name,
                        "success": result.success,
                        "duration": result.duration,
                        "timestamp": result.timestamp.isoformat(),
                        "error": result.error if result.error else None
                    }
                    for result in self.results
                ],
                "performance_metrics": self.performance_monitor.get_metrics_history(hours=1)
            }
            
            # Save report
            report_path = f"pipeline_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            logger.info(f"Pipeline report saved to {report_path}")
            
        except Exception as e:
            logger.error(f"Error generating pipeline report: {e}")

class AutomatedDeployment:
    """Handles automated deployment processes"""
    
    def __init__(self, integrations_manager=None):
        self.integrations_manager = integrations_manager
    
    def deploy_to_staging(self, project_path: str, image_name: str = "app-staging") -> bool:
        """Deploy application to staging environment"""
        try:
            if not self.integrations_manager:
                logger.error("Integrations manager not available")
                return False
            
            docker_integration = self.integrations_manager.get_integration("docker")
            if not docker_integration:
                logger.error("Docker integration not available")
                return False
            
            # Build Docker image
            dockerfile_path = os.path.join(project_path, "Dockerfile")
            if not os.path.exists(dockerfile_path):
                # Create Dockerfile if it doesn't exist
                docker_integration.create_dockerfile(project_path, "python", [])
            
            success = docker_integration.build_image(dockerfile_path, image_name, project_path)
            if not success:
                return False
            
            # Stop existing staging container
            try:
                subprocess.run(["docker", "stop", "app-staging"], check=False)
                subprocess.run(["docker", "rm", "app-staging"], check=False)
            except:
                pass
            
            # Run new staging container
            container_id = docker_integration.run_container(
                image_name,
                ports={"8000/tcp": 8000},
                environment={"ENV": "staging"}
            )
            
            if container_id:
                logger.info(f"Deployed to staging: container {container_id}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error deploying to staging: {e}")
            return False
    
    def deploy_to_production(self, project_path: str, image_name: str = "app-production") -> bool:
        """Deploy application to production environment"""
        try:
            # Additional checks for production deployment
            if not self.run_production_checks(project_path):
                logger.error("Production deployment checks failed")
                return False
            
            # Similar to staging but with production configurations
            # This would typically involve more sophisticated deployment strategies
            logger.info("Production deployment would be implemented here")
            return True
            
        except Exception as e:
            logger.error(f"Error deploying to production: {e}")
            return False
    
    def run_production_checks(self, project_path: str) -> bool:
        """Run additional checks before production deployment"""
        try:
            # Check for security vulnerabilities
            result = subprocess.run(
                ["python", "-m", "bandit", "-r", ".", "-f", "json"],
                cwd=project_path,
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                logger.warning("Security scan found issues")
                # In a real scenario, you might want to fail here
            
            # Check test coverage
            result = subprocess.run(
                ["python", "-m", "pytest", "--cov=.", "--cov-fail-under=80"],
                cwd=project_path,
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                logger.error("Test coverage below threshold")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error running production checks: {e}")
            return False

# Utility functions
def setup_project_cicd(project_path: str, language: str = "python"):
    """Set up CI/CD configuration for a project"""
    try:
        # Create CI/CD configuration
        pipeline = CICDPipeline(os.path.join(project_path, "pipeline_config.yaml"))
        
        # Create GitHub Actions workflow if GitHub integration is available
        github_workflow = create_github_workflow(language)
        workflows_dir = os.path.join(project_path, ".github", "workflows")
        os.makedirs(workflows_dir, exist_ok=True)
        
        with open(os.path.join(workflows_dir, "ci.yml"), 'w') as f:
            f.write(github_workflow)
        
        # Create Docker configuration
        if language == "python":
            create_python_docker_config(project_path)
        elif language == "javascript":
            create_javascript_docker_config(project_path)
        
        logger.info(f"CI/CD setup completed for {project_path}")
        return True
        
    except Exception as e:
        logger.error(f"Error setting up CI/CD: {e}")
        return False

def create_github_workflow(language: str) -> str:
    """Create GitHub Actions workflow configuration"""
    if language == "python":
        return """name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: [3.9, 3.10, 3.11]

    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v3
      with:
        python-version: ${{ matrix.python-version }}
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
        pip install pytest pytest-cov flake8 mypy bandit
    
    - name: Lint with flake8
      run: |
        flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
        flake8 . --count --exit-zero --max-complexity=10 --max-line-length=127 --statistics
    
    - name: Type check with mypy
      run: mypy .
    
    - name: Security scan with bandit
      run: bandit -r . -f json -o security_report.json
    
    - name: Test with pytest
      run: |
        pytest tests/ -v --cov=. --cov-report=xml
    
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml

  build:
    needs: test
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Build Docker image
      run: |
        docker build -t app:${{ github.sha }} .
        docker tag app:${{ github.sha }} app:latest
    
    - name: Run integration tests
      run: |
        docker run --rm app:${{ github.sha }} python -m pytest integration_tests/
"""
    else:
        return """name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Lint
      run: npm run lint
    
    - name: Test
      run: npm test
    
    - name: Build
      run: npm run build
"""

def create_python_docker_config(project_path: str):
    """Create Docker configuration for Python projects"""
    dockerfile_content = """FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    gcc \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create non-root user
RUN useradd --create-home --shell /bin/bash app \\
    && chown -R app:app /app
USER app

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \\
    CMD python -c "import requests; requests.get('http://localhost:8000/health')" || exit 1

EXPOSE 8000

CMD ["python", "app.py"]
"""
    
    with open(os.path.join(project_path, "Dockerfile"), 'w') as f:
        f.write(dockerfile_content)
    
    # Create .dockerignore
    dockerignore_content = """__pycache__
*.pyc
*.pyo
*.pyd
.Python
env
pip-log.txt
pip-delete-this-directory.txt
.tox
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.log
.git
.mypy_cache
.pytest_cache
.hypothesis
.venv
venv/
.venv/
"""
    
    with open(os.path.join(project_path, ".dockerignore"), 'w') as f:
        f.write(dockerignore_content)

def create_javascript_docker_config(project_path: str):
    """Create Docker configuration for JavaScript projects"""
    dockerfile_content = """FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application code
COPY . .

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001
USER nextjs

EXPOSE 3000

CMD ["npm", "start"]
"""
    
    with open(os.path.join(project_path, "Dockerfile"), 'w') as f:
        f.write(dockerfile_content)

if __name__ == "__main__":
    # Example usage
    pipeline = CICDPipeline()
    monitor = PerformanceMonitor()
    
    # Start monitoring
    monitor.start_monitoring()
    
    try:
        # Run pipeline
        results = pipeline.run_pipeline("/path/to/project")
        
        # Print results
        for result in results:
            status = "✓" if result.success else "✗"
            print(f"{status} {result.stage_name}: {result.duration:.2f}s")
    
    finally:
        # Stop monitoring
        monitor.stop_monitoring()

