import json
import sqlite3
import os
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class DataSource:
    id: str
    name: str
    type: str  # 'database', 'graphql', 'file', 'api'
    connection_string: str
    credentials: Dict[str, str]
    schema_info: Dict[str, Any]
    priority: int = 1
    active: bool = True
    created_at: str = ""
    updated_at: str = ""

class MCPDynamic:
    """
    Dynamic Meta-Context Processor
    Manages multiple data sources and provides intelligent context retrieval
    """
    
    def __init__(self, db_path: str = "mcp_data.db"):
        self.db_path = db_path
        self.init_database()
        
    def init_database(self):
        """Initialize the MCP database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create data sources table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS data_sources (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                connection_string TEXT,
                credentials TEXT,
                schema_info TEXT,
                priority INTEGER DEFAULT 1,
                active BOOLEAN DEFAULT 1,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        
        # Create context cache table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS context_cache (
                key TEXT PRIMARY KEY,
                value TEXT,
                source_id TEXT,
                created_at TEXT,
                expires_at TEXT
            )
        ''')
        
        # Create usage logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usage_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id TEXT,
                query TEXT,
                result_size INTEGER,
                execution_time REAL,
                timestamp TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_data_source(self, data_source: DataSource) -> bool:
        """Add a new data source"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            now = datetime.now().isoformat()
            data_source.created_at = now
            data_source.updated_at = now
            
            cursor.execute('''
                INSERT INTO data_sources 
                (id, name, type, connection_string, credentials, schema_info, priority, active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                data_source.id,
                data_source.name,
                data_source.type,
                data_source.connection_string,
                json.dumps(data_source.credentials),
                json.dumps(data_source.schema_info),
                data_source.priority,
                data_source.active,
                data_source.created_at,
                data_source.updated_at
            ))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Error adding data source: {e}")
            return False
    
    def get_data_sources(self, active_only: bool = True) -> List[DataSource]:
        """Retrieve all data sources"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = "SELECT * FROM data_sources"
        if active_only:
            query += " WHERE active = 1"
        query += " ORDER BY priority DESC"
        
        cursor.execute(query)
        rows = cursor.fetchall()
        conn.close()
        
        data_sources = []
        for row in rows:
            ds = DataSource(
                id=row[0],
                name=row[1],
                type=row[2],
                connection_string=row[3],
                credentials=json.loads(row[4]) if row[4] else {},
                schema_info=json.loads(row[5]) if row[5] else {},
                priority=row[6],
                active=bool(row[7]),
                created_at=row[8],
                updated_at=row[9]
            )
            data_sources.append(ds)
        
        return data_sources
    
    def retrieve_context(self, query: str, max_sources: int = 3) -> Dict[str, Any]:
        """
        Retrieve context from multiple data sources based on query
        This is a simplified version - in reality, this would use semantic search,
        vector embeddings, etc.
        """
        context = {
            "query": query,
            "sources": [],
            "timestamp": datetime.now().isoformat()
        }
        
        data_sources = self.get_data_sources()[:max_sources]
        
        for source in data_sources:
            try:
                source_context = self._query_data_source(source, query)
                if source_context:
                    context["sources"].append({
                        "source_id": source.id,
                        "source_name": source.name,
                        "source_type": source.type,
                        "data": source_context
                    })
            except Exception as e:
                print(f"Error querying source {source.name}: {e}")
        
        return context
    
    def _query_data_source(self, source: DataSource, query: str) -> Optional[Dict[str, Any]]:
        """
        Query a specific data source
        This is a placeholder - real implementation would handle different source types
        """
        if source.type == "file":
            return self._query_file_source(source, query)
        elif source.type == "database":
            return self._query_database_source(source, query)
        elif source.type == "api":
            return self._query_api_source(source, query)
        else:
            return {"message": f"Source type {source.type} not yet implemented"}
    
    def _query_file_source(self, source: DataSource, query: str) -> Dict[str, Any]:
        """Query file-based data source"""
        try:
            if os.path.exists(source.connection_string):
                with open(source.connection_string, 'r', encoding='utf-8') as f:
                    content = f.read()
                return {
                    "type": "file_content",
                    "content": content[:1000],  # Limit content size
                    "file_path": source.connection_string
                }
        except Exception as e:
            return {"error": str(e)}
        return {}
    
    def _query_database_source(self, source: DataSource, query: str) -> Dict[str, Any]:
        """Query database source - placeholder"""
        return {
            "type": "database_query",
            "message": "Database querying not yet implemented",
            "schema": source.schema_info
        }
    
    def _query_api_source(self, source: DataSource, query: str) -> Dict[str, Any]:
        """Query API source - placeholder"""
        return {
            "type": "api_query",
            "message": "API querying not yet implemented",
            "endpoint": source.connection_string
        }
    
    def log_usage(self, source_id: str, query: str, result_size: int, execution_time: float):
        """Log usage for analytics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO usage_logs (source_id, query, result_size, execution_time, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (source_id, query, result_size, execution_time, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()

# Example usage and testing
if __name__ == "__main__":
    mcp = MCPDynamic()
    
    # Add a sample file data source
    sample_source = DataSource(
        id="sample_code_repo",
        name="Sample Code Repository",
        type="file",
        connection_string="/home/ubuntu/meta-orchestrator/config.py",
        credentials={},
        schema_info={"file_type": "python", "description": "Configuration file"}
    )
    
    mcp.add_data_source(sample_source)
    
    # Test context retrieval
    context = mcp.retrieve_context("configuration settings")
    print(json.dumps(context, indent=2))


