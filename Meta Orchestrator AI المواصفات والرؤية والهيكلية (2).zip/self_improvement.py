import json
import sqlite3
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from knowledge_graph import KnowledgeGraph
from system_integrator import SystemIntegrator
import hashlib

@dataclass
class FeedbackData:
    """Represents feedback data for learning"""
    id: str
    code_hash: str
    task_description: str
    generated_code: str
    human_corrections: Optional[str]
    static_analysis_results: Dict[str, Any]
    test_results: Dict[str, Any]
    performance_metrics: Dict[str, Any]
    user_rating: Optional[float]  # 1-5 scale
    timestamp: str

@dataclass
class LearningPattern:
    """Represents a learned pattern"""
    pattern_id: str
    pattern_type: str  # 'error_correction', 'style_preference', 'performance_optimization'
    context: Dict[str, Any]
    pattern_data: Dict[str, Any]
    confidence_score: float
    usage_count: int
    success_rate: float
    created_at: str
    updated_at: str

class SelfImprovementSystem:
    """
    Self-Improvement System for Meta Orchestrator AI
    Implements RLHF-like mechanisms and continuous learning
    """
    
    def __init__(self, kg: KnowledgeGraph, db_path: str = "self_improvement.db"):
        self.kg = kg
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the self-improvement database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Feedback data table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback_data (
                id TEXT PRIMARY KEY,
                code_hash TEXT,
                task_description TEXT,
                generated_code TEXT,
                human_corrections TEXT,
                static_analysis_results TEXT,
                test_results TEXT,
                performance_metrics TEXT,
                user_rating REAL,
                timestamp TEXT
            )
        ''')
        
        # Learning patterns table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_patterns (
                pattern_id TEXT PRIMARY KEY,
                pattern_type TEXT,
                context TEXT,
                pattern_data TEXT,
                confidence_score REAL,
                usage_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 0.0,
                created_at TEXT,
                updated_at TEXT
            )
        ''')
        
        # Performance tracking table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT,
                metric_value REAL,
                context TEXT,
                timestamp TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def record_feedback(self, feedback: FeedbackData) -> bool:
        """Record feedback data for learning"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO feedback_data 
                (id, code_hash, task_description, generated_code, human_corrections,
                 static_analysis_results, test_results, performance_metrics, user_rating, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                feedback.id,
                feedback.code_hash,
                feedback.task_description,
                feedback.generated_code,
                feedback.human_corrections,
                json.dumps(feedback.static_analysis_results),
                json.dumps(feedback.test_results),
                json.dumps(feedback.performance_metrics),
                feedback.user_rating,
                feedback.timestamp
            ))
            
            conn.commit()
            conn.close()
            
            # Trigger pattern learning
            self._learn_from_feedback(feedback)
            
            return True
        except Exception as e:
            print(f"Error recording feedback: {e}")
            return False
    
    def _learn_from_feedback(self, feedback: FeedbackData):
        """Learn patterns from feedback data"""
        # Learn from human corrections
        if feedback.human_corrections:
            self._learn_correction_patterns(feedback)
        
        # Learn from static analysis results
        if feedback.static_analysis_results:
            self._learn_quality_patterns(feedback)
        
        # Learn from test results
        if feedback.test_results:
            self._learn_testing_patterns(feedback)
        
        # Learn from user ratings
        if feedback.user_rating:
            self._learn_preference_patterns(feedback)
    
    def _learn_correction_patterns(self, feedback: FeedbackData):
        """Learn from human corrections"""
        try:
            # Simple pattern: identify common correction types
            corrections = feedback.human_corrections
            original_code = feedback.generated_code
            
            # Calculate code similarity and differences
            diff_analysis = self._analyze_code_differences(original_code, corrections)
            
            pattern = LearningPattern(
                pattern_id=f"correction_{hashlib.md5(corrections.encode()).hexdigest()[:8]}",
                pattern_type="error_correction",
                context={
                    "task_type": self._classify_task(feedback.task_description),
                    "code_length": len(original_code),
                    "language": "Python"  # Assuming Python for now
                },
                pattern_data={
                    "common_corrections": diff_analysis,
                    "original_issues": self._identify_issues(original_code),
                    "correction_type": self._classify_correction(diff_analysis)
                },
                confidence_score=0.7,  # Initial confidence
                usage_count=1,
                success_rate=1.0,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat()
            )
            
            self._save_learning_pattern(pattern)
            
        except Exception as e:
            print(f"Error learning correction patterns: {e}")
    
    def _learn_quality_patterns(self, feedback: FeedbackData):
        """Learn from static analysis results"""
        try:
            analysis_results = feedback.static_analysis_results
            
            # Identify quality issues and their contexts
            quality_issues = []
            if 'flake8_errors' in analysis_results:
                quality_issues.extend(analysis_results['flake8_errors'])
            if 'mypy_errors' in analysis_results:
                quality_issues.extend(analysis_results['mypy_errors'])
            
            if quality_issues:
                pattern = LearningPattern(
                    pattern_id=f"quality_{hashlib.md5(str(quality_issues).encode()).hexdigest()[:8]}",
                    pattern_type="quality_improvement",
                    context={
                        "task_type": self._classify_task(feedback.task_description),
                        "code_complexity": self._estimate_complexity(feedback.generated_code)
                    },
                    pattern_data={
                        "common_issues": quality_issues,
                        "issue_frequency": self._calculate_issue_frequency(quality_issues),
                        "prevention_strategies": self._suggest_prevention_strategies(quality_issues)
                    },
                    confidence_score=0.8,
                    usage_count=1,
                    success_rate=0.0,  # Will be updated based on future performance
                    created_at=datetime.now().isoformat(),
                    updated_at=datetime.now().isoformat()
                )
                
                self._save_learning_pattern(pattern)
                
        except Exception as e:
            print(f"Error learning quality patterns: {e}")
    
    def _learn_testing_patterns(self, feedback: FeedbackData):
        """Learn from test results"""
        try:
            test_results = feedback.test_results
            
            if 'coverage' in test_results:
                coverage = test_results['coverage']
                
                pattern = LearningPattern(
                    pattern_id=f"testing_{hashlib.md5(feedback.code_hash.encode()).hexdigest()[:8]}",
                    pattern_type="testing_improvement",
                    context={
                        "task_type": self._classify_task(feedback.task_description),
                        "function_count": self._count_functions(feedback.generated_code)
                    },
                    pattern_data={
                        "coverage_achieved": coverage,
                        "test_quality": self._assess_test_quality(test_results),
                        "missing_test_areas": test_results.get('missing_coverage', [])
                    },
                    confidence_score=0.75,
                    usage_count=1,
                    success_rate=coverage / 100.0,  # Use coverage as success metric
                    created_at=datetime.now().isoformat(),
                    updated_at=datetime.now().isoformat()
                )
                
                self._save_learning_pattern(pattern)
                
        except Exception as e:
            print(f"Error learning testing patterns: {e}")
    
    def _learn_preference_patterns(self, feedback: FeedbackData):
        """Learn from user ratings and preferences"""
        try:
            rating = feedback.user_rating
            
            # Analyze what makes code highly rated
            code_features = self._extract_code_features(feedback.generated_code)
            
            pattern = LearningPattern(
                pattern_id=f"preference_{hashlib.md5(feedback.task_description.encode()).hexdigest()[:8]}",
                pattern_type="style_preference",
                context={
                    "task_type": self._classify_task(feedback.task_description),
                    "user_rating": rating
                },
                pattern_data={
                    "code_features": code_features,
                    "rating_correlation": self._calculate_feature_rating_correlation(code_features, rating),
                    "preferred_patterns": self._identify_preferred_patterns(code_features, rating)
                },
                confidence_score=min(rating / 5.0, 1.0),
                usage_count=1,
                success_rate=rating / 5.0,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat()
            )
            
            self._save_learning_pattern(pattern)
            
        except Exception as e:
            print(f"Error learning preference patterns: {e}")
    
    def _save_learning_pattern(self, pattern: LearningPattern):
        """Save a learning pattern to the database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO learning_patterns
                (pattern_id, pattern_type, context, pattern_data, confidence_score,
                 usage_count, success_rate, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                pattern.pattern_id,
                pattern.pattern_type,
                json.dumps(pattern.context),
                json.dumps(pattern.pattern_data),
                pattern.confidence_score,
                pattern.usage_count,
                pattern.success_rate,
                pattern.created_at,
                pattern.updated_at
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Error saving learning pattern: {e}")
    
    def get_improvement_suggestions(self, task_description: str, language: str = "Python") -> List[Dict[str, Any]]:
        """Get improvement suggestions based on learned patterns"""
        suggestions = []
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get relevant patterns
            cursor.execute('''
                SELECT pattern_type, context, pattern_data, confidence_score, success_rate
                FROM learning_patterns
                WHERE confidence_score > 0.5
                ORDER BY success_rate DESC, confidence_score DESC
                LIMIT 10
            ''')
            
            patterns = cursor.fetchall()
            conn.close()
            
            task_type = self._classify_task(task_description)
            
            for pattern in patterns:
                pattern_type, context_str, pattern_data_str, confidence, success_rate = pattern
                context = json.loads(context_str)
                pattern_data = json.loads(pattern_data_str)
                
                # Check if pattern is relevant to current task
                if context.get('task_type') == task_type or context.get('language') == language:
                    suggestion = {
                        "type": pattern_type,
                        "suggestion": self._generate_suggestion_text(pattern_type, pattern_data),
                        "confidence": confidence,
                        "success_rate": success_rate,
                        "applicable_context": context
                    }
                    suggestions.append(suggestion)
            
        except Exception as e:
            print(f"Error getting improvement suggestions: {e}")
        
        return suggestions
    
    def update_pattern_performance(self, pattern_id: str, success: bool):
        """Update pattern performance based on usage results"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get current pattern data
            cursor.execute('''
                SELECT usage_count, success_rate FROM learning_patterns WHERE pattern_id = ?
            ''', (pattern_id,))
            
            result = cursor.fetchone()
            if result:
                usage_count, current_success_rate = result
                
                # Update success rate using moving average
                new_usage_count = usage_count + 1
                success_value = 1.0 if success else 0.0
                new_success_rate = ((current_success_rate * usage_count) + success_value) / new_usage_count
                
                # Update confidence based on usage and success
                new_confidence = min(0.9, 0.5 + (new_success_rate * 0.4) + (min(new_usage_count, 10) * 0.05))
                
                cursor.execute('''
                    UPDATE learning_patterns 
                    SET usage_count = ?, success_rate = ?, confidence_score = ?, updated_at = ?
                    WHERE pattern_id = ?
                ''', (new_usage_count, new_success_rate, new_confidence, 
                      datetime.now().isoformat(), pattern_id))
                
                conn.commit()
            
            conn.close()
            
        except Exception as e:
            print(f"Error updating pattern performance: {e}")
    
    # Helper methods (simplified implementations)
    def _analyze_code_differences(self, original: str, corrected: str) -> Dict[str, Any]:
        """Analyze differences between original and corrected code"""
        return {
            "length_change": len(corrected) - len(original),
            "line_changes": len(corrected.split('\n')) - len(original.split('\n')),
            "has_type_hints": ":" in corrected and ":" not in original,
            "has_docstring": '"""' in corrected and '"""' not in original
        }
    
    def _classify_task(self, task_description: str) -> str:
        """Classify task type based on description"""
        task_lower = task_description.lower()
        if "function" in task_lower:
            return "function_creation"
        elif "class" in task_lower:
            return "class_creation"
        elif "test" in task_lower:
            return "test_creation"
        elif "api" in task_lower:
            return "api_development"
        else:
            return "general_coding"
    
    def _identify_issues(self, code: str) -> List[str]:
        """Identify common issues in code"""
        issues = []
        if "print(" in code:
            issues.append("contains_print_statements")
        if not code.strip().startswith('"""') and not code.strip().startswith("'''"):
            issues.append("missing_docstring")
        if "->" not in code and "def " in code:
            issues.append("missing_return_type_hint")
        return issues
    
    def _classify_correction(self, diff_analysis: Dict[str, Any]) -> str:
        """Classify the type of correction made"""
        if diff_analysis.get("has_type_hints"):
            return "type_hint_addition"
        elif diff_analysis.get("has_docstring"):
            return "documentation_addition"
        elif diff_analysis.get("length_change", 0) > 0:
            return "code_expansion"
        else:
            return "code_refinement"
    
    def _estimate_complexity(self, code: str) -> str:
        """Estimate code complexity"""
        lines = len(code.split('\n'))
        if lines < 10:
            return "low"
        elif lines < 50:
            return "medium"
        else:
            return "high"
    
    def _calculate_issue_frequency(self, issues: List[str]) -> Dict[str, int]:
        """Calculate frequency of different issues"""
        frequency = {}
        for issue in issues:
            issue_type = issue.split(':')[0] if ':' in issue else issue
            frequency[issue_type] = frequency.get(issue_type, 0) + 1
        return frequency
    
    def _suggest_prevention_strategies(self, issues: List[str]) -> List[str]:
        """Suggest strategies to prevent common issues"""
        strategies = []
        issue_types = set(issue.split(':')[0] if ':' in issue else issue for issue in issues)
        
        if 'E302' in issue_types:  # Expected 2 blank lines
            strategies.append("Add proper spacing between functions and classes")
        if 'F401' in issue_types:  # Unused import
            strategies.append("Remove unused imports")
        if 'E501' in issue_types:  # Line too long
            strategies.append("Break long lines into multiple lines")
        
        return strategies
    
    def _count_functions(self, code: str) -> int:
        """Count number of functions in code"""
        return code.count("def ")
    
    def _assess_test_quality(self, test_results: Dict[str, Any]) -> str:
        """Assess the quality of tests"""
        coverage = test_results.get('coverage', 0)
        if coverage >= 90:
            return "excellent"
        elif coverage >= 70:
            return "good"
        elif coverage >= 50:
            return "fair"
        else:
            return "poor"
    
    def _extract_code_features(self, code: str) -> Dict[str, Any]:
        """Extract features from code for analysis"""
        return {
            "has_docstrings": '"""' in code or "'''" in code,
            "has_type_hints": "->" in code,
            "function_count": code.count("def "),
            "class_count": code.count("class "),
            "line_count": len(code.split('\n')),
            "has_error_handling": "try:" in code or "except:" in code,
            "has_logging": "logging" in code or "print(" in code
        }
    
    def _calculate_feature_rating_correlation(self, features: Dict[str, Any], rating: float) -> Dict[str, float]:
        """Calculate correlation between features and rating"""
        # Simplified correlation calculation
        correlations = {}
        for feature, value in features.items():
            if isinstance(value, bool):
                correlations[feature] = rating / 5.0 if value else 0.0
            elif isinstance(value, (int, float)):
                correlations[feature] = min(value / 10.0, 1.0) * (rating / 5.0)
        return correlations
    
    def _identify_preferred_patterns(self, features: Dict[str, Any], rating: float) -> List[str]:
        """Identify preferred patterns based on high ratings"""
        patterns = []
        if rating >= 4.0:  # High rating
            if features.get("has_docstrings"):
                patterns.append("comprehensive_documentation")
            if features.get("has_type_hints"):
                patterns.append("type_annotations")
            if features.get("has_error_handling"):
                patterns.append("robust_error_handling")
        return patterns
    
    def _generate_suggestion_text(self, pattern_type: str, pattern_data: Dict[str, Any]) -> str:
        """Generate human-readable suggestion text"""
        if pattern_type == "error_correction":
            return f"Based on past corrections, consider: {', '.join(pattern_data.get('common_corrections', {}).keys())}"
        elif pattern_type == "quality_improvement":
            issues = pattern_data.get('common_issues', [])
            return f"Avoid common quality issues: {', '.join(issues[:3])}"
        elif pattern_type == "testing_improvement":
            coverage = pattern_data.get('coverage_achieved', 0)
            return f"Aim for test coverage above {coverage}% based on successful patterns"
        elif pattern_type == "style_preference":
            patterns = pattern_data.get('preferred_patterns', [])
            return f"Users prefer code with: {', '.join(patterns)}"
        else:
            return "Apply learned best practices from similar tasks"

# Example usage
if __name__ == "__main__":
    from knowledge_graph import KnowledgeGraph
    
    kg = KnowledgeGraph()
    improvement_system = SelfImprovementSystem(kg)
    
    # Example feedback
    feedback = FeedbackData(
        id="test_feedback_1",
        code_hash="abc123",
        task_description="Create a function to calculate factorial",
        generated_code="def factorial(n):\n    return n * factorial(n-1) if n > 1 else 1",
        human_corrections="def factorial(n: int) -> int:\n    \"\"\"Calculate factorial of n.\"\"\"\n    return n * factorial(n-1) if n > 1 else 1",
        static_analysis_results={"flake8_errors": ["E302: expected 2 blank lines"]},
        test_results={"coverage": 85, "tests_passed": 5, "tests_failed": 0},
        performance_metrics={"execution_time": 0.001},
        user_rating=4.5,
        timestamp=datetime.now().isoformat()
    )
    
    improvement_system.record_feedback(feedback)
    
    # Get suggestions
    suggestions = improvement_system.get_improvement_suggestions("Create a function to calculate fibonacci")
    print(f"Got {len(suggestions)} improvement suggestions")
    for suggestion in suggestions:
        print(f"- {suggestion['suggestion']} (confidence: {suggestion['confidence']:.2f})")

