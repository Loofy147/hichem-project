
### {{phase_name}} – Generate Unit Tests for {{module_name}}

Context: You have just generated the code in `{{module_file}}`.

Prompt:
"""
Write unit tests covering all functions and edge cases in `{{module_file}}`.
Use {{test_framework}}.
Ensure at least {{coverage_target}} coverage.
Mock external dependencies where needed.
Provide clear test names and comments.
"""


