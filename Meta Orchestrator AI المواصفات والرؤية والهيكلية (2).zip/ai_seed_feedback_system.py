import os
import json
import sqlite3
import asyncio
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
import logging
import time
import hashlib
from enum import Enum
import statistics

from ai_seed import AISeed, Experience, TaskType, LearningPhase, LearningStrategy
from llm_evaluator import LLMEvaluator, EvaluationResult, LearningAssessment, EvaluationCriteria
from knowledge_graph import KnowledgeGraph

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FeedbackType(Enum):
    """أنواع التغذية الراجعة"""
    PERFORMANCE_FEEDBACK = "performance_feedback"
    LEARNING_FEEDBACK = "learning_feedback"
    STRATEGY_FEEDBACK = "strategy_feedback"
    BEHAVIORAL_FEEDBACK = "behavioral_feedback"
    ADAPTIVE_FEEDBACK = "adaptive_feedback"

class ImprovementAction(Enum):
    """إجراءات التحسين"""
    ADJUST_LEARNING_RATE = "adjust_learning_rate"
    CHANGE_STRATEGY = "change_strategy"
    FOCUS_ON_WEAKNESS = "focus_on_weakness"
    INCREASE_DIFFICULTY = "increase_difficulty"
    DECREASE_DIFFICULTY = "decrease_difficulty"
    DIVERSIFY_TRAINING = "diversify_training"
    REINFORCE_STRENGTHS = "reinforce_strengths"
    RESET_PARAMETERS = "reset_parameters"

@dataclass
class FeedbackItem:
    """عنصر التغذية الراجعة"""
    feedback_id: str
    seed_id: str
    feedback_type: FeedbackType
    source: str  # evaluation, performance, user, system
    content: str
    severity: float  # 0.0 - 1.0
    actionable: bool
    suggested_actions: List[ImprovementAction]
    context: Dict[str, Any]
    timestamp: datetime

@dataclass
class ImprovementPlan:
    """خطة التحسين"""
    plan_id: str
    seed_id: str
    target_areas: List[str]
    improvement_actions: List[Dict[str, Any]]
    expected_outcomes: Dict[str, float]
    timeline: Dict[str, datetime]
    priority_level: float
    success_metrics: Dict[str, float]
    created_at: datetime
    status: str  # planned, active, completed, cancelled

@dataclass
class AdaptationRecord:
    """سجل التكيف"""
    adaptation_id: str
    seed_id: str
    trigger_event: str
    adaptation_type: str
    old_parameters: Dict[str, Any]
    new_parameters: Dict[str, Any]
    adaptation_reason: str
    expected_impact: float
    actual_impact: Optional[float]
    timestamp: datetime

class AISeedFeedbackSystem:
    """نظام التغذية الراجعة والتحسين لبذرة الذكاء الاصطناعي"""
    
    def __init__(self, orchestrator=None, llm_evaluator=None, knowledge_graph=None):
        self.orchestrator = orchestrator
        self.llm_evaluator = llm_evaluator or LLMEvaluator()
        self.knowledge_graph = knowledge_graph or KnowledgeGraph()
        
        # إعدادات النظام
        self.feedback_config = {
            "feedback_frequency": 5,  # كل 5 تقييمات
            "adaptation_threshold": 0.1,  # عتبة التكيف
            "improvement_patience": 10,  # عدد التقييمات قبل التدخل
            "performance_window": 20,  # نافزة تحليل الأداء
            "learning_rate_bounds": (0.001, 0.1),
            "strategy_change_cooldown": 50,  # فترة انتظار تغيير الاستراتيجية
            "auto_adaptation": True,
            "feedback_aggregation": True
        }
        
        # قاعدة بيانات التغذية الراجعة
        self.feedback_db_path = "ai_seed_feedback.db"
        self.init_feedback_database()
        
        # ذاكرة التغذية الراجعة
        self.feedback_cache = {}
        self.adaptation_history = {}
        self.improvement_plans = {}
        
        # إحصائيات النظام
        self.system_stats = {
            "total_feedback_items": 0,
            "successful_adaptations": 0,
            "improvement_plans_created": 0,
            "average_improvement_rate": 0.0,
            "adaptation_success_rate": 0.0
        }
        
        # حالة النظام
        self.is_running = False
        self.feedback_tasks = []
        
        logger.info("تم تهيئة نظام التغذية الراجعة والتحسين")
    
    def init_feedback_database(self):
        """تهيئة قاعدة بيانات التغذية الراجعة"""
        with sqlite3.connect(self.feedback_db_path) as conn:
            # جدول عناصر التغذية الراجعة
            conn.execute("""
                CREATE TABLE IF NOT EXISTS feedback_items (
                    feedback_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    feedback_type TEXT NOT NULL,
                    source TEXT NOT NULL,
                    content TEXT NOT NULL,
                    severity REAL NOT NULL,
                    actionable INTEGER NOT NULL,
                    suggested_actions TEXT,
                    context TEXT,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول خطط التحسين
            conn.execute("""
                CREATE TABLE IF NOT EXISTS improvement_plans (
                    plan_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    target_areas TEXT,
                    improvement_actions TEXT,
                    expected_outcomes TEXT,
                    timeline TEXT,
                    priority_level REAL NOT NULL,
                    success_metrics TEXT,
                    created_at TEXT NOT NULL,
                    status TEXT NOT NULL
                )
            """)
            
            # جدول سجلات التكيف
            conn.execute("""
                CREATE TABLE IF NOT EXISTS adaptation_records (
                    adaptation_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    trigger_event TEXT NOT NULL,
                    adaptation_type TEXT NOT NULL,
                    old_parameters TEXT,
                    new_parameters TEXT,
                    adaptation_reason TEXT,
                    expected_impact REAL NOT NULL,
                    actual_impact REAL,
                    timestamp TEXT NOT NULL
                )
            """)
            
            # جدول إحصائيات النظام
            conn.execute("""
                CREATE TABLE IF NOT EXISTS system_statistics (
                    timestamp TEXT PRIMARY KEY,
                    total_feedback_items INTEGER,
                    successful_adaptations INTEGER,
                    improvement_plans_created INTEGER,
                    average_improvement_rate REAL,
                    adaptation_success_rate REAL
                )
            """)
    
    async def start_feedback_system(self):
        """بدء نظام التغذية الراجعة"""
        if self.is_running:
            logger.warning("نظام التغذية الراجعة يعمل بالفعل")
            return
        
        self.is_running = True
        logger.info("بدء نظام التغذية الراجعة والتحسين")
        
        # بدء معالج التغذية الراجعة
        self.feedback_tasks.append(
            asyncio.create_task(self.feedback_processor())
        )
        
        # بدء مراقب التكيف
        self.feedback_tasks.append(
            asyncio.create_task(self.adaptation_monitor())
        )
        
        # بدء مراقب الإحصائيات
        self.feedback_tasks.append(
            asyncio.create_task(self.stats_monitor())
        )
    
    async def process_evaluation_feedback(self, seed_id: str, evaluation_result: EvaluationResult):
        """معالجة التغذية الراجعة من التقييم"""
        try:
            feedback_items = []
            
            # تحليل النقاط الإجمالية
            if evaluation_result.overall_score < 0.3:
                feedback_items.append(FeedbackItem(
                    feedback_id=f"perf_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    seed_id=seed_id,
                    feedback_type=FeedbackType.PERFORMANCE_FEEDBACK,
                    source="evaluation",
                    content=f"الأداء منخفض جداً ({evaluation_result.overall_score:.2f}). يحتاج تدخل فوري.",
                    severity=0.9,
                    actionable=True,
                    suggested_actions=[
                        ImprovementAction.DECREASE_DIFFICULTY,
                        ImprovementAction.FOCUS_ON_WEAKNESS,
                        ImprovementAction.ADJUST_LEARNING_RATE
                    ],
                    context={"evaluation_id": evaluation_result.request_id},
                    timestamp=datetime.now()
                ))
            elif evaluation_result.overall_score > 0.8:
                feedback_items.append(FeedbackItem(
                    feedback_id=f"perf_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    seed_id=seed_id,
                    feedback_type=FeedbackType.PERFORMANCE_FEEDBACK,
                    source="evaluation",
                    content=f"أداء ممتاز ({evaluation_result.overall_score:.2f}). يمكن زيادة التحدي.",
                    severity=0.3,
                    actionable=True,
                    suggested_actions=[
                        ImprovementAction.INCREASE_DIFFICULTY,
                        ImprovementAction.DIVERSIFY_TRAINING
                    ],
                    context={"evaluation_id": evaluation_result.request_id},
                    timestamp=datetime.now()
                ))
            
            # تحليل نقاط الضعف
            for weakness in evaluation_result.weaknesses:
                feedback_items.append(FeedbackItem(
                    feedback_id=f"weak_{seed_id}_{hashlib.md5(weakness.encode()).hexdigest()[:8]}",
                    seed_id=seed_id,
                    feedback_type=FeedbackType.LEARNING_FEEDBACK,
                    source="evaluation",
                    content=f"نقطة ضعف محددة: {weakness}",
                    severity=0.6,
                    actionable=True,
                    suggested_actions=[ImprovementAction.FOCUS_ON_WEAKNESS],
                    context={"weakness_area": weakness},
                    timestamp=datetime.now()
                ))
            
            # تحليل معايير الأداء
            for criteria, score in evaluation_result.criteria_scores.items():
                if score < 0.4:
                    feedback_items.append(FeedbackItem(
                        feedback_id=f"crit_{seed_id}_{criteria}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        seed_id=seed_id,
                        feedback_type=FeedbackType.LEARNING_FEEDBACK,
                        source="evaluation",
                        content=f"أداء ضعيف في معيار {criteria}: {score:.2f}",
                        severity=0.7,
                        actionable=True,
                        suggested_actions=[ImprovementAction.FOCUS_ON_WEAKNESS],
                        context={"criteria": criteria, "score": score},
                        timestamp=datetime.now()
                    ))
            
            # حفظ عناصر التغذية الراجعة
            for feedback_item in feedback_items:
                self.save_feedback_item(feedback_item)
            
            # تحليل الحاجة للتكيف
            await self.analyze_adaptation_need(seed_id)
            
            logger.info(f"تم معالجة {len(feedback_items)} عنصر تغذية راجعة للبذرة {seed_id}")
            
        except Exception as e:
            logger.error(f"خطأ في معالجة التغذية الراجعة من التقييم: {e}")
    
    async def analyze_adaptation_need(self, seed_id: str):
        """تحليل الحاجة للتكيف"""
        try:
            # جلب التقييمات الأخيرة
            recent_evaluations = self.get_recent_evaluations(seed_id, self.feedback_config["performance_window"])
            
            if len(recent_evaluations) < 5:
                logger.info(f"عدد التقييمات غير كافي للتحليل: {len(recent_evaluations)}")
                return
            
            # تحليل الاتجاهات
            scores = [eval_data["overall_score"] for eval_data in recent_evaluations]
            
            # حساب الاتجاه
            trend = self.calculate_performance_trend(scores)
            
            # حساب التباين
            variance = statistics.variance(scores) if len(scores) > 1 else 0
            
            # حساب متوسط الأداء
            avg_performance = statistics.mean(scores)
            
            # تحديد الحاجة للتكيف
            adaptation_needed = False
            adaptation_reason = ""
            
            if trend < -self.feedback_config["adaptation_threshold"]:
                adaptation_needed = True
                adaptation_reason = f"اتجاه هبوطي في الأداء: {trend:.3f}"
            elif avg_performance < 0.3:
                adaptation_needed = True
                adaptation_reason = f"متوسط أداء منخفض: {avg_performance:.3f}"
            elif variance > 0.1:
                adaptation_needed = True
                adaptation_reason = f"تباين عالي في الأداء: {variance:.3f}"
            
            if adaptation_needed and self.feedback_config["auto_adaptation"]:
                await self.trigger_adaptation(seed_id, adaptation_reason, {
                    "trend": trend,
                    "variance": variance,
                    "avg_performance": avg_performance,
                    "recent_scores": scores[-5:]
                })
            
        except Exception as e:
            logger.error(f"خطأ في تحليل الحاجة للتكيف: {e}")
    
    def calculate_performance_trend(self, scores: List[float]) -> float:
        """حساب اتجاه الأداء"""
        try:
            if len(scores) < 2:
                return 0.0
            
            # استخدام الانحدار الخطي البسيط
            n = len(scores)
            x = list(range(n))
            
            # حساب المتوسطات
            x_mean = sum(x) / n
            y_mean = sum(scores) / n
            
            # حساب الميل
            numerator = sum((x[i] - x_mean) * (scores[i] - y_mean) for i in range(n))
            denominator = sum((x[i] - x_mean) ** 2 for i in range(n))
            
            if denominator == 0:
                return 0.0
            
            slope = numerator / denominator
            return slope
            
        except Exception as e:
            logger.error(f"خطأ في حساب اتجاه الأداء: {e}")
            return 0.0
    
    async def trigger_adaptation(self, seed_id: str, reason: str, context: Dict[str, Any]):
        """تشغيل التكيف"""
        try:
            # فحص فترة الانتظار
            if not self.can_adapt(seed_id):
                logger.info(f"البذرة {seed_id} في فترة انتظار التكيف")
                return
            
            # تحديد نوع التكيف المطلوب
            adaptation_actions = self.determine_adaptation_actions(context)
            
            # تنفيذ التكيف
            for action in adaptation_actions:
                await self.execute_adaptation_action(seed_id, action, reason, context)
            
            # تسجيل التكيف
            self.record_adaptation_attempt(seed_id, reason, adaptation_actions)
            
            logger.info(f"تم تشغيل التكيف للبذرة {seed_id}: {reason}")
            
        except Exception as e:
            logger.error(f"خطأ في تشغيل التكيف: {e}")
    
    def can_adapt(self, seed_id: str) -> bool:
        """فحص إمكانية التكيف"""
        try:
            if seed_id not in self.adaptation_history:
                return True
            
            last_adaptation = self.adaptation_history[seed_id]
            cooldown_period = timedelta(minutes=self.feedback_config["strategy_change_cooldown"])
            
            return datetime.now() - last_adaptation > cooldown_period
            
        except Exception as e:
            logger.error(f"خطأ في فحص إمكانية التكيف: {e}")
            return False
    
    def determine_adaptation_actions(self, context: Dict[str, Any]) -> List[ImprovementAction]:
        """تحديد إجراءات التكيف"""
        try:
            actions = []
            
            avg_performance = context.get("avg_performance", 0.5)
            trend = context.get("trend", 0.0)
            variance = context.get("variance", 0.0)
            
            # تحديد الإجراءات بناءً على السياق
            if avg_performance < 0.3:
                actions.extend([
                    ImprovementAction.DECREASE_DIFFICULTY,
                    ImprovementAction.ADJUST_LEARNING_RATE,
                    ImprovementAction.FOCUS_ON_WEAKNESS
                ])
            elif avg_performance > 0.8:
                actions.extend([
                    ImprovementAction.INCREASE_DIFFICULTY,
                    ImprovementAction.DIVERSIFY_TRAINING
                ])
            
            if trend < -0.1:
                actions.extend([
                    ImprovementAction.CHANGE_STRATEGY,
                    ImprovementAction.ADJUST_LEARNING_RATE
                ])
            
            if variance > 0.15:
                actions.extend([
                    ImprovementAction.CHANGE_STRATEGY,
                    ImprovementAction.FOCUS_ON_WEAKNESS
                ])
            
            # إزالة التكرارات
            return list(set(actions))
            
        except Exception as e:
            logger.error(f"خطأ في تحديد إجراءات التكيف: {e}")
            return [ImprovementAction.ADJUST_LEARNING_RATE]
    
    async def execute_adaptation_action(
        self, 
        seed_id: str, 
        action: ImprovementAction, 
        reason: str, 
        context: Dict[str, Any]
    ):
        """تنفيذ إجراء التكيف"""
        try:
            # الحصول على البذرة (افتراضياً من النظام)
            seed = self.get_seed_instance(seed_id)
            if not seed:
                logger.error(f"لم يتم العثور على البذرة {seed_id}")
                return
            
            old_parameters = self.get_seed_parameters(seed)
            new_parameters = old_parameters.copy()
            
            # تنفيذ الإجراء
            if action == ImprovementAction.ADJUST_LEARNING_RATE:
                current_lr = old_parameters.get("learning_rate", 0.01)
                if context.get("avg_performance", 0.5) < 0.4:
                    new_lr = max(current_lr * 0.8, self.feedback_config["learning_rate_bounds"][0])
                else:
                    new_lr = min(current_lr * 1.2, self.feedback_config["learning_rate_bounds"][1])
                new_parameters["learning_rate"] = new_lr
                
            elif action == ImprovementAction.CHANGE_STRATEGY:
                current_strategy = old_parameters.get("primary_strategy", LearningStrategy.IMITATION)
                strategies = list(LearningStrategy)
                current_index = strategies.index(current_strategy)
                new_strategy = strategies[(current_index + 1) % len(strategies)]
                new_parameters["primary_strategy"] = new_strategy
                
            elif action == ImprovementAction.FOCUS_ON_WEAKNESS:
                new_parameters["focus_mode"] = "weakness"
                new_parameters["exploration_rate"] = max(
                    old_parameters.get("exploration_rate", 0.1) * 0.7, 0.05
                )
                
            elif action == ImprovementAction.INCREASE_DIFFICULTY:
                new_parameters["difficulty_preference"] = min(
                    old_parameters.get("difficulty_preference", 0.5) + 0.1, 1.0
                )
                
            elif action == ImprovementAction.DECREASE_DIFFICULTY:
                new_parameters["difficulty_preference"] = max(
                    old_parameters.get("difficulty_preference", 0.5) - 0.1, 0.0
                )
                
            elif action == ImprovementAction.DIVERSIFY_TRAINING:
                new_parameters["task_diversity"] = min(
                    old_parameters.get("task_diversity", 0.5) + 0.2, 1.0
                )
                
            elif action == ImprovementAction.REINFORCE_STRENGTHS:
                new_parameters["focus_mode"] = "strength"
                new_parameters["exploitation_rate"] = min(
                    old_parameters.get("exploitation_rate", 0.7) + 0.1, 0.9
                )
                
            elif action == ImprovementAction.RESET_PARAMETERS:
                new_parameters = self.get_default_parameters()
            
            # تطبيق المعاملات الجديدة
            self.apply_seed_parameters(seed, new_parameters)
            
            # تسجيل التكيف
            adaptation_record = AdaptationRecord(
                adaptation_id=f"adapt_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                seed_id=seed_id,
                trigger_event=reason,
                adaptation_type=action.value,
                old_parameters=old_parameters,
                new_parameters=new_parameters,
                adaptation_reason=reason,
                expected_impact=self.estimate_adaptation_impact(action, context),
                actual_impact=None,  # سيتم تحديثه لاحقاً
                timestamp=datetime.now()
            )
            
            self.save_adaptation_record(adaptation_record)
            
            logger.info(f"تم تنفيذ إجراء التكيف {action.value} للبذرة {seed_id}")
            
        except Exception as e:
            logger.error(f"خطأ في تنفيذ إجراء التكيف: {e}")
    
    def get_seed_instance(self, seed_id: str) -> Optional[AISeed]:
        """الحصول على مثيل البذرة"""
        # هذا يحتاج للتكامل مع نظام إدارة البذور
        # للآن، نعيد None
        return None
    
    def get_seed_parameters(self, seed: AISeed) -> Dict[str, Any]:
        """الحصول على معاملات البذرة"""
        try:
            return {
                "learning_rate": getattr(seed, 'learning_rate', 0.01),
                "primary_strategy": getattr(seed, 'primary_strategy', LearningStrategy.IMITATION),
                "exploration_rate": getattr(seed, 'exploration_rate', 0.1),
                "exploitation_rate": getattr(seed, 'exploitation_rate', 0.7),
                "difficulty_preference": getattr(seed, 'difficulty_preference', 0.5),
                "task_diversity": getattr(seed, 'task_diversity', 0.5),
                "focus_mode": getattr(seed, 'focus_mode', "balanced")
            }
        except Exception as e:
            logger.error(f"خطأ في الحصول على معاملات البذرة: {e}")
            return self.get_default_parameters()
    
    def get_default_parameters(self) -> Dict[str, Any]:
        """الحصول على المعاملات الافتراضية"""
        return {
            "learning_rate": 0.01,
            "primary_strategy": LearningStrategy.IMITATION,
            "exploration_rate": 0.1,
            "exploitation_rate": 0.7,
            "difficulty_preference": 0.5,
            "task_diversity": 0.5,
            "focus_mode": "balanced"
        }
    
    def apply_seed_parameters(self, seed: AISeed, parameters: Dict[str, Any]):
        """تطبيق المعاملات على البذرة"""
        try:
            for param, value in parameters.items():
                if hasattr(seed, param):
                    setattr(seed, param, value)
        except Exception as e:
            logger.error(f"خطأ في تطبيق معاملات البذرة: {e}")
    
    def estimate_adaptation_impact(self, action: ImprovementAction, context: Dict[str, Any]) -> float:
        """تقدير تأثير التكيف"""
        try:
            # تقديرات أولية بناءً على نوع الإجراء
            impact_estimates = {
                ImprovementAction.ADJUST_LEARNING_RATE: 0.1,
                ImprovementAction.CHANGE_STRATEGY: 0.2,
                ImprovementAction.FOCUS_ON_WEAKNESS: 0.15,
                ImprovementAction.INCREASE_DIFFICULTY: 0.05,
                ImprovementAction.DECREASE_DIFFICULTY: 0.1,
                ImprovementAction.DIVERSIFY_TRAINING: 0.08,
                ImprovementAction.REINFORCE_STRENGTHS: 0.06,
                ImprovementAction.RESET_PARAMETERS: 0.3
            }
            
            base_impact = impact_estimates.get(action, 0.1)
            
            # تعديل التقدير بناءً على السياق
            avg_performance = context.get("avg_performance", 0.5)
            if avg_performance < 0.3:
                base_impact *= 1.5  # تأثير أكبر للأداء المنخفض
            elif avg_performance > 0.8:
                base_impact *= 0.7  # تأثير أقل للأداء العالي
            
            return min(base_impact, 1.0)
            
        except Exception as e:
            logger.error(f"خطأ في تقدير تأثير التكيف: {e}")
            return 0.1
    
    def record_adaptation_attempt(self, seed_id: str, reason: str, actions: List[ImprovementAction]):
        """تسجيل محاولة التكيف"""
        try:
            self.adaptation_history[seed_id] = datetime.now()
            logger.info(f"تم تسجيل محاولة التكيف للبذرة {seed_id}: {[a.value for a in actions]}")
        except Exception as e:
            logger.error(f"خطأ في تسجيل محاولة التكيف: {e}")
    
    async def create_improvement_plan(self, seed_id: str, assessment: LearningAssessment) -> ImprovementPlan:
        """إنشاء خطة تحسين"""
        try:
            # تحليل نقاط الضعف
            target_areas = []
            improvement_actions = []
            
            # تحديد المجالات المستهدفة
            if assessment.average_score < 0.5:
                target_areas.append("overall_performance")
            
            if assessment.improvement_rate < 0:
                target_areas.append("learning_progression")
            
            if assessment.consistency_score < 0.6:
                target_areas.append("performance_consistency")
            
            # تحليل تقدم المهارات
            for skill, progression in assessment.skill_progression.items():
                if progression < -0.1:
                    target_areas.append(f"skill_{skill}")
            
            # إنشاء إجراءات التحسين
            for area in target_areas:
                if area == "overall_performance":
                    improvement_actions.append({
                        "action": "intensive_training",
                        "description": "تدريب مكثف على المهام الأساسية",
                        "duration_days": 7,
                        "expected_improvement": 0.2
                    })
                elif area == "learning_progression":
                    improvement_actions.append({
                        "action": "strategy_optimization",
                        "description": "تحسين استراتيجيات التعلم",
                        "duration_days": 5,
                        "expected_improvement": 0.15
                    })
                elif area == "performance_consistency":
                    improvement_actions.append({
                        "action": "stability_training",
                        "description": "تدريب على الثبات والاستقرار",
                        "duration_days": 10,
                        "expected_improvement": 0.1
                    })
                elif area.startswith("skill_"):
                    skill_name = area.replace("skill_", "")
                    improvement_actions.append({
                        "action": "skill_focus",
                        "description": f"التركيز على تحسين مهارة {skill_name}",
                        "duration_days": 3,
                        "expected_improvement": 0.1,
                        "target_skill": skill_name
                    })
            
            # حساب النتائج المتوقعة
            expected_outcomes = {
                "overall_score_improvement": sum(
                    action.get("expected_improvement", 0) for action in improvement_actions
                ),
                "consistency_improvement": 0.1 if "performance_consistency" in target_areas else 0,
                "learning_velocity_improvement": 0.05 if "learning_progression" in target_areas else 0
            }
            
            # إنشاء الجدول الزمني
            timeline = {
                "start_date": datetime.now(),
                "end_date": datetime.now() + timedelta(days=max(
                    action.get("duration_days", 7) for action in improvement_actions
                ) if improvement_actions else 7),
                "milestones": []
            }
            
            # حساب مستوى الأولوية
            priority_level = min(1.0, (1.0 - assessment.average_score) + 
                                abs(assessment.improvement_rate) * 2)
            
            # مقاييس النجاح
            success_metrics = {
                "target_score": min(1.0, assessment.average_score + expected_outcomes["overall_score_improvement"]),
                "target_consistency": min(1.0, assessment.consistency_score + expected_outcomes["consistency_improvement"]),
                "target_learning_velocity": assessment.learning_velocity + expected_outcomes["learning_velocity_improvement"]
            }
            
            # إنشاء خطة التحسين
            plan = ImprovementPlan(
                plan_id=f"plan_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                seed_id=seed_id,
                target_areas=target_areas,
                improvement_actions=improvement_actions,
                expected_outcomes=expected_outcomes,
                timeline=timeline,
                priority_level=priority_level,
                success_metrics=success_metrics,
                created_at=datetime.now(),
                status="planned"
            )
            
            # حفظ الخطة
            self.save_improvement_plan(plan)
            
            # تحديث الإحصائيات
            self.system_stats["improvement_plans_created"] += 1
            
            logger.info(f"تم إنشاء خطة تحسين للبذرة {seed_id} مع {len(improvement_actions)} إجراء")
            
            return plan
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء خطة التحسين: {e}")
            return self.create_default_improvement_plan(seed_id)
    
    def create_default_improvement_plan(self, seed_id: str) -> ImprovementPlan:
        """إنشاء خطة تحسين افتراضية"""
        return ImprovementPlan(
            plan_id=f"default_plan_{seed_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            seed_id=seed_id,
            target_areas=["general_improvement"],
            improvement_actions=[{
                "action": "general_training",
                "description": "تدريب عام لتحسين الأداء",
                "duration_days": 7,
                "expected_improvement": 0.1
            }],
            expected_outcomes={"overall_score_improvement": 0.1},
            timeline={
                "start_date": datetime.now(),
                "end_date": datetime.now() + timedelta(days=7)
            },
            priority_level=0.5,
            success_metrics={"target_score": 0.6},
            created_at=datetime.now(),
            status="planned"
        )
    
    def get_recent_evaluations(self, seed_id: str, limit: int) -> List[Dict[str, Any]]:
        """جلب التقييمات الأخيرة"""
        try:
            # هذا يحتاج للتكامل مع قاعدة بيانات التقييم
            # للآن، نعيد قائمة فارغة
            return []
        except Exception as e:
            logger.error(f"خطأ في جلب التقييمات الأخيرة: {e}")
            return []
    
    def save_feedback_item(self, feedback_item: FeedbackItem):
        """حفظ عنصر التغذية الراجعة"""
        try:
            with sqlite3.connect(self.feedback_db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO feedback_items 
                    (feedback_id, seed_id, feedback_type, source, content, severity,
                     actionable, suggested_actions, context, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    feedback_item.feedback_id,
                    feedback_item.seed_id,
                    feedback_item.feedback_type.value,
                    feedback_item.source,
                    feedback_item.content,
                    feedback_item.severity,
                    int(feedback_item.actionable),
                    json.dumps([action.value for action in feedback_item.suggested_actions]),
                    json.dumps(feedback_item.context),
                    feedback_item.timestamp.isoformat()
                ))
                
            self.system_stats["total_feedback_items"] += 1
            
        except Exception as e:
            logger.error(f"خطأ في حفظ عنصر التغذية الراجعة: {e}")
    
    def save_improvement_plan(self, plan: ImprovementPlan):
        """حفظ خطة التحسين"""
        try:
            with sqlite3.connect(self.feedback_db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO improvement_plans 
                    (plan_id, seed_id, target_areas, improvement_actions, expected_outcomes,
                     timeline, priority_level, success_metrics, created_at, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    plan.plan_id,
                    plan.seed_id,
                    json.dumps(plan.target_areas),
                    json.dumps(plan.improvement_actions),
                    json.dumps(plan.expected_outcomes),
                    json.dumps(plan.timeline, default=str),
                    plan.priority_level,
                    json.dumps(plan.success_metrics),
                    plan.created_at.isoformat(),
                    plan.status
                ))
                
        except Exception as e:
            logger.error(f"خطأ في حفظ خطة التحسين: {e}")
    
    def save_adaptation_record(self, record: AdaptationRecord):
        """حفظ سجل التكيف"""
        try:
            with sqlite3.connect(self.feedback_db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO adaptation_records 
                    (adaptation_id, seed_id, trigger_event, adaptation_type, old_parameters,
                     new_parameters, adaptation_reason, expected_impact, actual_impact, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record.adaptation_id,
                    record.seed_id,
                    record.trigger_event,
                    record.adaptation_type,
                    json.dumps(record.old_parameters),
                    json.dumps(record.new_parameters),
                    record.adaptation_reason,
                    record.expected_impact,
                    record.actual_impact,
                    record.timestamp.isoformat()
                ))
                
        except Exception as e:
            logger.error(f"خطأ في حفظ سجل التكيف: {e}")
    
    async def feedback_processor(self):
        """معالج التغذية الراجعة"""
        while self.is_running:
            try:
                # معالجة التغذية الراجعة المعلقة
                await asyncio.sleep(30)  # فحص كل 30 ثانية
                
                # هنا يمكن إضافة منطق معالجة التغذية الراجعة المعلقة
                
            except Exception as e:
                logger.error(f"خطأ في معالج التغذية الراجعة: {e}")
                await asyncio.sleep(60)
    
    async def adaptation_monitor(self):
        """مراقب التكيف"""
        while self.is_running:
            try:
                # مراقبة التكيفات النشطة
                await asyncio.sleep(300)  # فحص كل 5 دقائق
                
                # هنا يمكن إضافة منطق مراقبة التكيفات
                
            except Exception as e:
                logger.error(f"خطأ في مراقب التكيف: {e}")
                await asyncio.sleep(300)
    
    async def stats_monitor(self):
        """مراقب الإحصائيات"""
        while self.is_running:
            try:
                # حفظ الإحصائيات كل 10 دقائق
                await asyncio.sleep(600)
                
                with sqlite3.connect(self.feedback_db_path) as conn:
                    conn.execute("""
                        INSERT INTO system_statistics 
                        (timestamp, total_feedback_items, successful_adaptations,
                         improvement_plans_created, average_improvement_rate, adaptation_success_rate)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (
                        datetime.now().isoformat(),
                        self.system_stats["total_feedback_items"],
                        self.system_stats["successful_adaptations"],
                        self.system_stats["improvement_plans_created"],
                        self.system_stats["average_improvement_rate"],
                        self.system_stats["adaptation_success_rate"]
                    ))
                
            except Exception as e:
                logger.error(f"خطأ في مراقب الإحصائيات: {e}")
    
    async def stop_feedback_system(self):
        """إيقاف نظام التغذية الراجعة"""
        logger.info("إيقاف نظام التغذية الراجعة")
        
        self.is_running = False
        
        # إلغاء جميع المهام
        for task in self.feedback_tasks:
            task.cancel()
        
        # انتظار انتهاء المهام
        if self.feedback_tasks:
            await asyncio.gather(*self.feedback_tasks, return_exceptions=True)
        
        logger.info("تم إيقاف نظام التغذية الراجعة")
    
    def get_feedback_statistics(self) -> Dict[str, Any]:
        """الحصول على إحصائيات التغذية الراجعة"""
        try:
            with sqlite3.connect(self.feedback_db_path) as conn:
                # إحصائيات عامة
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_feedback,
                        AVG(severity) as avg_severity,
                        SUM(CASE WHEN actionable = 1 THEN 1 ELSE 0 END) as actionable_count
                    FROM feedback_items
                """)
                general_stats = cursor.fetchone()
                
                # إحصائيات التكيف
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_adaptations,
                        AVG(expected_impact) as avg_expected_impact,
                        AVG(actual_impact) as avg_actual_impact
                    FROM adaptation_records
                    WHERE actual_impact IS NOT NULL
                """)
                adaptation_stats = cursor.fetchone()
                
                # إحصائيات خطط التحسين
                cursor = conn.execute("""
                    SELECT 
                        COUNT(*) as total_plans,
                        AVG(priority_level) as avg_priority,
                        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_plans
                    FROM improvement_plans
                """)
                plan_stats = cursor.fetchone()
                
                return {
                    "general": {
                        "total_feedback_items": general_stats[0] or 0,
                        "average_severity": general_stats[1] or 0.0,
                        "actionable_items": general_stats[2] or 0
                    },
                    "adaptations": {
                        "total_adaptations": adaptation_stats[0] or 0,
                        "average_expected_impact": adaptation_stats[1] or 0.0,
                        "average_actual_impact": adaptation_stats[2] or 0.0
                    },
                    "improvement_plans": {
                        "total_plans": plan_stats[0] or 0,
                        "average_priority": plan_stats[1] or 0.0,
                        "completed_plans": plan_stats[2] or 0
                    },
                    "current_stats": self.system_stats
                }
                
        except Exception as e:
            logger.error(f"خطأ في الحصول على إحصائيات التغذية الراجعة: {e}")
            return {}

# مثال على الاستخدام
async def main():
    """مثال على الاستخدام"""
    feedback_system = AISeedFeedbackSystem()
    
    try:
        # بدء النظام
        await feedback_system.start_feedback_system()
        
        # محاكاة تقييم
        from llm_evaluator import EvaluationResult
        
        mock_evaluation = EvaluationResult(
            request_id="test_eval_001",
            seed_id="test_seed_001",
            overall_score=0.25,  # أداء منخفض
            criteria_scores={"correctness": 0.2, "efficiency": 0.3},
            detailed_feedback="الأداء يحتاج تحسين كبير",
            suggestions=["تحسين المنطق", "مراجعة الخوارزمية"],
            strengths=["محاولة جيدة"],
            weaknesses=["منطق خاطئ", "كفاءة منخفضة"],
            learning_insights={"needs_basic_training": True},
            confidence_level=0.8,
            evaluation_time=2.5,
            llm_provider="openai_gpt4o",
            timestamp=datetime.now()
        )
        
        # معالجة التغذية الراجعة
        await feedback_system.process_evaluation_feedback("test_seed_001", mock_evaluation)
        
        # عرض الإحصائيات
        stats = feedback_system.get_feedback_statistics()
        print(f"إحصائيات التغذية الراجعة: {json.dumps(stats, indent=2, ensure_ascii=False)}")
        
        # انتظار قليل لمعالجة التكيف
        await asyncio.sleep(5)
        
    except KeyboardInterrupt:
        print("إيقاف البرنامج...")
    finally:
        await feedback_system.stop_feedback_system()

if __name__ == "__main__":
    asyncio.run(main())

