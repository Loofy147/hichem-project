#!/usr/bin/env python3
"""
AI Seed Demo Script
===================

هذا السكريبت يعرض قدرات بذرة الذكاء الاصطناعي الأساسية
ويوضح كيفية استخدام النظام للتعلم من التحديات والتحسن المستمر.

الاستخدام:
    python ai_seed_demo.py

المتطلبات:
    - تثبيت جميع التبعيات من requirements.txt
    - إعداد متغيرات البيئة في ملف .env
    - تهيئة قاعدة البيانات
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

# استيراد مكونات النظام
from ai_seed import AISeed, LearningStrategy, LearningPhase
from ai_seed_challenge_integration import AISeedTrainer
from llm_evaluator import LLMEvaluator
from ai_seed_feedback_system import AISeedFeedbackSystem
from ai_seed_data_ingestion import DataIngestionEngine

# إعداد السجلات
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AISeedDemo:
    """فئة العرض التوضيحي لبذرة الذكاء الاصطناعي"""
    
    def __init__(self):
        """تهيئة العرض التوضيحي"""
        self.seed = None
        self.trainer = None
        self.evaluator = None
        self.feedback_system = None
        self.ingestion_engine = None
        
    async def initialize_system(self):
        """تهيئة جميع مكونات النظام"""
        logger.info("🚀 بدء تهيئة نظام بذرة الذكاء الاصطناعي...")
        
        try:
            # إنشاء بذرة جديدة
            self.seed = AISeed(
                seed_id="demo_seed_001",
                initial_config={
                    "learning_rate": 0.02,
                    "primary_strategy": LearningStrategy.IMITATION,
                    "difficulty_preference": 0.3
                }
            )
            logger.info(f"✅ تم إنشاء البذرة: {self.seed.seed_id}")
            
            # تهيئة المدرب
            self.trainer = AISeedTrainer()
            await self.trainer.add_seed(self.seed)
            logger.info("✅ تم تهيئة مدرب البذور")
            
            # تهيئة المقيم
            self.evaluator = LLMEvaluator()
            logger.info("✅ تم تهيئة مقيم LLM")
            
            # تهيئة نظام التغذية الراجعة
            self.feedback_system = AISeedFeedbackSystem()
            logger.info("✅ تم تهيئة نظام التغذية الراجعة")
            
            # تهيئة محرك استيعاب البيانات
            self.ingestion_engine = DataIngestionEngine()
            logger.info("✅ تم تهيئة محرك استيعاب البيانات")
            
            logger.info("🎉 تم تهيئة النظام بنجاح!")
            
        except Exception as e:
            logger.error(f"❌ خطأ في تهيئة النظام: {e}")
            raise
    
    def create_sample_challenges(self) -> List[Dict[str, Any]]:
        """إنشاء تحديات نموذجية للعرض التوضيحي"""
        challenges = [
            {
                "id": "factorial_challenge",
                "type": "algorithm",
                "difficulty": 0.2,
                "title": "حساب المضروب",
                "description": "اكتب دالة لحساب مضروب عدد صحيح موجب",
                "requirements": [
                    "يجب أن تتعامل مع الحالات الحدية (0, 1)",
                    "يجب أن تكون فعالة من ناحية الأداء",
                    "يجب أن تتضمن معالجة للأخطاء"
                ],
                "test_cases": [
                    {"input": 0, "expected_output": 1},
                    {"input": 1, "expected_output": 1},
                    {"input": 5, "expected_output": 120},
                    {"input": 10, "expected_output": 3628800}
                ],
                "hints": [
                    "يمكن استخدام التكرار أو الاستدعاء المتكرر",
                    "تذكر أن 0! = 1",
                    "تأكد من التعامل مع الأرقام السالبة"
                ]
            },
            {
                "id": "fibonacci_challenge",
                "type": "algorithm",
                "difficulty": 0.4,
                "title": "متتالية فيبوناتشي",
                "description": "اكتب دالة لحساب الرقم النوني في متتالية فيبوناتشي",
                "requirements": [
                    "يجب أن تكون فعالة (تجنب الحسابات المتكررة)",
                    "يجب أن تتعامل مع الأرقام الكبيرة",
                    "يجب أن تتضمن معالجة للحالات الاستثنائية"
                ],
                "test_cases": [
                    {"input": 0, "expected_output": 0},
                    {"input": 1, "expected_output": 1},
                    {"input": 10, "expected_output": 55},
                    {"input": 20, "expected_output": 6765}
                ],
                "hints": [
                    "استخدم البرمجة الديناميكية لتحسين الأداء",
                    "يمكن استخدام مصفوفة لحفظ النتائج المحسوبة",
                    "تذكر أن F(0) = 0, F(1) = 1"
                ]
            },
            {
                "id": "sorting_challenge",
                "type": "algorithm",
                "difficulty": 0.6,
                "title": "خوارزمية الترتيب",
                "description": "اكتب دالة لترتيب مصفوفة من الأرقام بطريقة فعالة",
                "requirements": [
                    "يجب أن تكون التعقيد الزمني O(n log n) أو أفضل",
                    "يجب أن تتعامل مع المصفوفات الفارغة",
                    "يجب أن تحافظ على استقرار الترتيب للعناصر المتساوية"
                ],
                "test_cases": [
                    {"input": [], "expected_output": []},
                    {"input": [1], "expected_output": [1]},
                    {"input": [3, 1, 4, 1, 5, 9, 2, 6], "expected_output": [1, 1, 2, 3, 4, 5, 6, 9]},
                    {"input": [5, 4, 3, 2, 1], "expected_output": [1, 2, 3, 4, 5]}
                ],
                "hints": [
                    "يمكن استخدام Merge Sort أو Quick Sort",
                    "تأكد من التعامل مع الحالات الحدية",
                    "اختبر الأداء مع مصفوفات كبيرة"
                ]
            }
        ]
        return challenges
    
    async def demonstrate_learning_cycle(self):
        """عرض دورة التعلم الكاملة للبذرة"""
        logger.info("📚 بدء عرض دورة التعلم...")
        
        challenges = self.create_sample_challenges()
        
        for i, challenge in enumerate(challenges, 1):
            logger.info(f"\n{'='*60}")
            logger.info(f"🎯 التحدي {i}: {challenge['title']}")
            logger.info(f"📝 الوصف: {challenge['description']}")
            logger.info(f"⚡ مستوى الصعوبة: {challenge['difficulty']}")
            logger.info(f"{'='*60}")
            
            try:
                # تدريب البذرة على التحدي
                logger.info("🏃‍♂️ بدء التدريب...")
                training_result = await self.trainer.train_seed_on_challenge(
                    self.seed.seed_id, 
                    challenge
                )
                
                if training_result["success"]:
                    logger.info("✅ تم إكمال التدريب بنجاح")
                    logger.info(f"💡 الحل المقترح: {training_result['solution'][:100]}...")
                    
                    # تقييم الحل
                    logger.info("🔍 بدء التقييم...")
                    evaluation_result = await self.evaluator.evaluate_solution(
                        seed_id=self.seed.seed_id,
                        task_description=challenge['description'],
                        solution=training_result['solution'],
                        criteria=["correctness", "efficiency", "clarity", "creativity"]
                    )
                    
                    logger.info(f"📊 النقاط الإجمالية: {evaluation_result.overall_score:.2f}")
                    logger.info(f"💪 نقاط القوة: {', '.join(evaluation_result.strengths)}")
                    if evaluation_result.weaknesses:
                        logger.info(f"🔧 نقاط التحسين: {', '.join(evaluation_result.weaknesses)}")
                    
                    # معالجة التغذية الراجعة
                    logger.info("🔄 معالجة التغذية الراجعة...")
                    await self.feedback_system.process_evaluation_feedback(
                        self.seed.seed_id,
                        evaluation_result
                    )
                    
                else:
                    logger.warning(f"⚠️ فشل في التدريب: {training_result.get('error', 'خطأ غير معروف')}")
                
                # عرض إحصائيات البذرة
                await self.display_seed_statistics()
                
                # انتظار قصير بين التحديات
                await asyncio.sleep(2)
                
            except Exception as e:
                logger.error(f"❌ خطأ في معالجة التحدي: {e}")
    
    async def display_seed_statistics(self):
        """عرض إحصائيات البذرة الحالية"""
        logger.info("\n📈 إحصائيات البذرة:")
        
        # الحصول على إحصائيات الأداء
        stats = self.seed.get_performance_statistics()
        logger.info(f"   📊 معدل النجاح: {stats['success_rate']:.1%}")
        logger.info(f"   🚀 سرعة التعلم: {stats['learning_velocity']:.3f}")
        logger.info(f"   🎯 ثبات الأداء: {stats['consistency_score']:.3f}")
        logger.info(f"   📚 عدد التجارب: {stats['total_experiences']}")
        
        # عرض المرحلة الحالية
        logger.info(f"   🌱 المرحلة الحالية: {self.seed.current_phase.value}")
        
        # عرض الاستراتيجيات
        logger.info("   🧠 توزيع الاستراتيجيات:")
        for strategy, weight in self.seed.learning_strategies.items():
            logger.info(f"      {strategy.value}: {weight:.2f}")
    
    async def demonstrate_data_ingestion(self):
        """عرض قدرات استيعاب البيانات"""
        logger.info("\n🔄 عرض استيعاب البيانات...")
        
        # إنشاء مصدر بيانات نموذجي
        sample_data_source = {
            "source_id": "demo_code_samples",
            "source_type": "local_files",
            "config": {
                "file_patterns": ["*.py"],
                "max_files": 10,
                "quality_threshold": 0.7
            }
        }
        
        try:
            # إضافة مصدر البيانات
            await self.ingestion_engine.add_data_source(sample_data_source)
            logger.info("✅ تم إضافة مصدر البيانات")
            
            # بدء استيعاب البيانات
            ingestion_result = await self.ingestion_engine.start_ingestion(
                self.seed.seed_id
            )
            
            if ingestion_result["success"]:
                logger.info(f"✅ تم استيعاب {ingestion_result['processed_items']} عنصر")
                logger.info(f"📊 متوسط الجودة: {ingestion_result['average_quality']:.2f}")
            else:
                logger.warning(f"⚠️ مشكلة في الاستيعاب: {ingestion_result.get('error')}")
                
        except Exception as e:
            logger.error(f"❌ خطأ في استيعاب البيانات: {e}")
    
    async def demonstrate_adaptation(self):
        """عرض قدرات التكيف التلقائي"""
        logger.info("\n🔧 عرض التكيف التلقائي...")
        
        try:
            # محاكاة أداء منخفض لتشغيل التكيف
            logger.info("📉 محاكاة انخفاض في الأداء...")
            
            # إضافة تجارب بأداء منخفض
            for i in range(5):
                low_score_experience = {
                    "task_id": f"low_performance_task_{i}",
                    "solution": "# حل بسيط وغير محسن",
                    "score": 0.2 + (i * 0.05),  # نقاط منخفضة
                    "feedback": "يحتاج تحسين كبير",
                    "timestamp": datetime.now()
                }
                self.seed.brain.add_experience(low_score_experience)
            
            # تشغيل تحليل الأداء
            performance_analysis = self.feedback_system.analyze_performance_trends(
                self.seed.get_recent_scores(10)
            )
            
            logger.info(f"📊 تحليل الاتجاه: {performance_analysis['trend_direction']}")
            logger.info(f"📈 قوة الاتجاه: {performance_analysis['trend_strength']:.3f}")
            
            # تشغيل التكيف إذا لزم الأمر
            if performance_analysis["needs_adaptation"]:
                logger.info("🔄 تشغيل التكيف التلقائي...")
                
                adaptation_result = await self.feedback_system.trigger_adaptation(
                    self.seed.seed_id,
                    performance_analysis
                )
                
                if adaptation_result["success"]:
                    logger.info("✅ تم تطبيق التكيف بنجاح")
                    logger.info(f"🔧 الإجراءات المطبقة: {len(adaptation_result['applied_actions'])}")
                    
                    for action in adaptation_result['applied_actions']:
                        logger.info(f"   • {action}")
                else:
                    logger.warning("⚠️ فشل في تطبيق التكيف")
            else:
                logger.info("ℹ️ لا يحتاج النظام للتكيف حالياً")
                
        except Exception as e:
            logger.error(f"❌ خطأ في عرض التكيف: {e}")
    
    async def generate_final_report(self):
        """إنشاء تقرير نهائي للعرض التوضيحي"""
        logger.info("\n📋 إنشاء التقرير النهائي...")
        
        try:
            # جمع الإحصائيات النهائية
            final_stats = self.seed.get_performance_statistics()
            
            # إنشاء تقييم التعلم
            learning_assessment = await self.evaluator.assess_learning_progress(
                self.seed.seed_id,
                period="session"
            )
            
            # إنشاء التقرير
            report = {
                "demo_summary": {
                    "seed_id": self.seed.seed_id,
                    "demo_duration": "عرض توضيحي كامل",
                    "challenges_completed": len(self.create_sample_challenges()),
                    "final_phase": self.seed.current_phase.value
                },
                "performance_metrics": final_stats,
                "learning_assessment": {
                    "average_score": learning_assessment.average_score,
                    "improvement_rate": learning_assessment.improvement_rate,
                    "skill_progression": learning_assessment.skill_progression,
                    "learning_insights": learning_assessment.learning_insights
                },
                "system_capabilities_demonstrated": [
                    "إنشاء وتهيئة بذرة ذكاء اصطناعي",
                    "التدريب على تحديات متنوعة",
                    "التقييم بواسطة LLM خارجي",
                    "التغذية الراجعة والتحسين التلقائي",
                    "استيعاب البيانات من مصادر متنوعة",
                    "التكيف مع تغيرات الأداء",
                    "مراقبة التقدم والإحصائيات"
                ]
            }
            
            # حفظ التقرير
            report_filename = f"ai_seed_demo_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_filename, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2, default=str)
            
            logger.info(f"📄 تم حفظ التقرير في: {report_filename}")
            
            # عرض ملخص التقرير
            logger.info("\n🎉 ملخص العرض التوضيحي:")
            logger.info(f"   🆔 معرف البذرة: {report['demo_summary']['seed_id']}")
            logger.info(f"   🎯 التحديات المكتملة: {report['demo_summary']['challenges_completed']}")
            logger.info(f"   🌱 المرحلة النهائية: {report['demo_summary']['final_phase']}")
            logger.info(f"   📊 معدل النجاح النهائي: {final_stats['success_rate']:.1%}")
            logger.info(f"   🚀 سرعة التعلم: {final_stats['learning_velocity']:.3f}")
            
            return report
            
        except Exception as e:
            logger.error(f"❌ خطأ في إنشاء التقرير: {e}")
            return None
    
    async def run_complete_demo(self):
        """تشغيل العرض التوضيحي الكامل"""
        logger.info("🎬 بدء العرض التوضيحي الكامل لبذرة الذكاء الاصطناعي")
        logger.info("=" * 80)
        
        try:
            # 1. تهيئة النظام
            await self.initialize_system()
            
            # 2. عرض دورة التعلم
            await self.demonstrate_learning_cycle()
            
            # 3. عرض استيعاب البيانات
            await self.demonstrate_data_ingestion()
            
            # 4. عرض التكيف التلقائي
            await self.demonstrate_adaptation()
            
            # 5. إنشاء التقرير النهائي
            final_report = await self.generate_final_report()
            
            logger.info("\n🎊 تم إكمال العرض التوضيحي بنجاح!")
            logger.info("=" * 80)
            
            return final_report
            
        except Exception as e:
            logger.error(f"❌ خطأ في العرض التوضيحي: {e}")
            raise

async def main():
    """الدالة الرئيسية للعرض التوضيحي"""
    demo = AISeedDemo()
    
    try:
        report = await demo.run_complete_demo()
        
        if report:
            print("\n" + "="*80)
            print("🎉 تم إكمال العرض التوضيحي بنجاح!")
            print("📄 تم إنشاء تقرير مفصل للنتائج")
            print("🚀 النظام جاهز للاستخدام الفعلي")
            print("="*80)
        else:
            print("\n❌ فشل في إكمال العرض التوضيحي")
            
    except KeyboardInterrupt:
        print("\n⏹️ تم إيقاف العرض التوضيحي بواسطة المستخدم")
    except Exception as e:
        print(f"\n❌ خطأ في العرض التوضيحي: {e}")

if __name__ == "__main__":
    # تشغيل العرض التوضيحي
    asyncio.run(main())

