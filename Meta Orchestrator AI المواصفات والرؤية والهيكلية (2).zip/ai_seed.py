import os
import json
import sqlite3
import numpy as np
import pickle
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
import logging
import hashlib
import random
from concurrent.futures import ThreadPoolExecutor
import threading
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LearningPhase(Enum):
    INITIALIZATION = "initialization"
    EXPLORATION = "exploration"
    EXPLOITATION = "exploitation"
    REFINEMENT = "refinement"
    MASTERY = "mastery"

class TaskType(Enum):
    CODE_GENERATION = "code_generation"
    CODE_REVIEW = "code_review"
    DEBUGGING = "debugging"
    OPTIMIZATION = "optimization"
    TESTING = "testing"
    DOCUMENTATION = "documentation"

class LearningStrategy(Enum):
    IMITATION = "imitation"  # تقليد الحلول الناجحة
    EXPLORATION = "exploration"  # استكشاف حلول جديدة
    REINFORCEMENT = "reinforcement"  # التعلم من التغذية الراجعة
    TRANSFER = "transfer"  # نقل المعرفة بين المهام

@dataclass
class Experience:
    """تمثل تجربة تعلم واحدة"""
    id: str
    task_type: TaskType
    input_data: Dict[str, Any]
    output_data: Dict[str, Any]
    context: Dict[str, Any]
    feedback_score: float
    external_evaluation: Optional[Dict[str, Any]] = None
    timestamp: datetime = None
    learning_phase: LearningPhase = LearningPhase.EXPLORATION
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if isinstance(self.task_type, str):
            self.task_type = TaskType(self.task_type)
        if isinstance(self.learning_phase, str):
            self.learning_phase = LearningPhase(self.learning_phase)

@dataclass
class LearningPattern:
    """نمط تعلم مكتشف"""
    pattern_id: str
    pattern_type: str
    conditions: Dict[str, Any]
    actions: Dict[str, Any]
    success_rate: float
    usage_count: int
    last_used: datetime
    confidence: float

@dataclass
class KnowledgeUnit:
    """وحدة معرفة أساسية"""
    id: str
    concept: str
    description: str
    examples: List[Dict[str, Any]]
    relationships: List[str]
    confidence: float
    usage_frequency: int
    last_updated: datetime

class AISeedBrain:
    """دماغ بذرة الذكاء الاصطناعي - يحتوي على المعرفة والذاكرة"""
    
    def __init__(self, brain_path: str = "ai_seed_brain.db"):
        self.brain_path = brain_path
        self.experiences = []
        self.patterns = {}
        self.knowledge_units = {}
        self.current_strategy = LearningStrategy.EXPLORATION
        self.learning_phase = LearningPhase.INITIALIZATION
        self.confidence_threshold = 0.7
        self.exploration_rate = 0.3
        
        # إحصائيات التعلم
        self.total_experiences = 0
        self.successful_experiences = 0
        self.learning_rate = 0.1
        self.adaptation_speed = 0.05
        
        self.init_brain_database()
        self.load_brain_state()
    
    def init_brain_database(self):
        """تهيئة قاعدة بيانات الدماغ"""
        with sqlite3.connect(self.brain_path) as conn:
            # جدول التجارب
            conn.execute("""
                CREATE TABLE IF NOT EXISTS experiences (
                    id TEXT PRIMARY KEY,
                    task_type TEXT NOT NULL,
                    input_data TEXT NOT NULL,
                    output_data TEXT NOT NULL,
                    context TEXT NOT NULL,
                    feedback_score REAL NOT NULL,
                    external_evaluation TEXT,
                    timestamp TEXT NOT NULL,
                    learning_phase TEXT NOT NULL
                )
            """)
            
            # جدول الأنماط المكتشفة
            conn.execute("""
                CREATE TABLE IF NOT EXISTS learning_patterns (
                    pattern_id TEXT PRIMARY KEY,
                    pattern_type TEXT NOT NULL,
                    conditions TEXT NOT NULL,
                    actions TEXT NOT NULL,
                    success_rate REAL NOT NULL,
                    usage_count INTEGER NOT NULL,
                    last_used TEXT NOT NULL,
                    confidence REAL NOT NULL
                )
            """)
            
            # جدول وحدات المعرفة
            conn.execute("""
                CREATE TABLE IF NOT EXISTS knowledge_units (
                    id TEXT PRIMARY KEY,
                    concept TEXT NOT NULL,
                    description TEXT NOT NULL,
                    examples TEXT NOT NULL,
                    relationships TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    usage_frequency INTEGER NOT NULL,
                    last_updated TEXT NOT NULL
                )
            """)
            
            # جدول حالة الدماغ
            conn.execute("""
                CREATE TABLE IF NOT EXISTS brain_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
    
    def save_experience(self, experience: Experience):
        """حفظ تجربة جديدة"""
        with sqlite3.connect(self.brain_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO experiences 
                (id, task_type, input_data, output_data, context, feedback_score, 
                 external_evaluation, timestamp, learning_phase)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                experience.id,
                experience.task_type.value,
                json.dumps(experience.input_data),
                json.dumps(experience.output_data),
                json.dumps(experience.context),
                experience.feedback_score,
                json.dumps(experience.external_evaluation) if experience.external_evaluation else None,
                experience.timestamp.isoformat(),
                experience.learning_phase.value
            ))
        
        self.experiences.append(experience)
        self.total_experiences += 1
        if experience.feedback_score > 0.7:
            self.successful_experiences += 1
        
        # تحليل التجربة لاستخراج أنماط جديدة
        self.analyze_experience(experience)
    
    def analyze_experience(self, experience: Experience):
        """تحليل التجربة لاستخراج أنماط التعلم"""
        try:
            # استخراج الخصائص المهمة من التجربة
            features = self.extract_features(experience)
            
            # البحث عن أنماط مشابهة
            similar_patterns = self.find_similar_patterns(features)
            
            if similar_patterns:
                # تحديث الأنماط الموجودة
                for pattern in similar_patterns:
                    self.update_pattern(pattern, experience)
            else:
                # إنشاء نمط جديد إذا كانت التجربة ناجحة
                if experience.feedback_score > self.confidence_threshold:
                    new_pattern = self.create_pattern_from_experience(experience, features)
                    self.save_pattern(new_pattern)
        
        except Exception as e:
            logger.error(f"خطأ في تحليل التجربة: {e}")
    
    def extract_features(self, experience: Experience) -> Dict[str, Any]:
        """استخراج الخصائص المهمة من التجربة"""
        features = {
            "task_type": experience.task_type.value,
            "input_complexity": self.calculate_complexity(experience.input_data),
            "output_quality": experience.feedback_score,
            "context_size": len(str(experience.context)),
            "learning_phase": experience.learning_phase.value
        }
        
        # استخراج خصائص إضافية حسب نوع المهمة
        if experience.task_type == TaskType.CODE_GENERATION:
            features.update(self.extract_code_features(experience))
        elif experience.task_type == TaskType.CODE_REVIEW:
            features.update(self.extract_review_features(experience))
        
        return features
    
    def extract_code_features(self, experience: Experience) -> Dict[str, Any]:
        """استخراج خصائص خاصة بتوليد الكود"""
        code = experience.output_data.get("code", "")
        return {
            "code_length": len(code),
            "function_count": code.count("def "),
            "class_count": code.count("class "),
            "import_count": code.count("import "),
            "comment_ratio": code.count("#") / max(len(code.split("\n")), 1)
        }
    
    def extract_review_features(self, experience: Experience) -> Dict[str, Any]:
        """استخراج خصائص خاصة بمراجعة الكود"""
        review = experience.output_data.get("review", "")
        return {
            "review_length": len(review),
            "issues_found": review.count("issue"),
            "suggestions_count": review.count("suggest"),
            "severity_mentions": review.count("critical") + review.count("major")
        }
    
    def calculate_complexity(self, data: Dict[str, Any]) -> float:
        """حساب تعقيد البيانات"""
        try:
            data_str = json.dumps(data)
            return len(data_str) / 1000.0  # تطبيع التعقيد
        except:
            return 0.0
    
    def find_similar_patterns(self, features: Dict[str, Any]) -> List[LearningPattern]:
        """البحث عن أنماط مشابهة"""
        similar_patterns = []
        
        for pattern in self.patterns.values():
            similarity = self.calculate_similarity(features, pattern.conditions)
            if similarity > 0.8:  # عتبة التشابه
                similar_patterns.append(pattern)
        
        return similar_patterns
    
    def calculate_similarity(self, features1: Dict[str, Any], features2: Dict[str, Any]) -> float:
        """حساب التشابه بين مجموعتين من الخصائص"""
        common_keys = set(features1.keys()) & set(features2.keys())
        if not common_keys:
            return 0.0
        
        similarity_sum = 0.0
        for key in common_keys:
            val1, val2 = features1[key], features2[key]
            
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                # للقيم الرقمية
                max_val = max(abs(val1), abs(val2), 1)
                similarity_sum += 1 - abs(val1 - val2) / max_val
            elif val1 == val2:
                # للقيم النصية المتطابقة
                similarity_sum += 1.0
            else:
                # للقيم النصية المختلفة
                similarity_sum += 0.0
        
        return similarity_sum / len(common_keys)
    
    def create_pattern_from_experience(self, experience: Experience, features: Dict[str, Any]) -> LearningPattern:
        """إنشاء نمط جديد من التجربة"""
        pattern_id = hashlib.md5(
            f"{experience.task_type.value}_{experience.timestamp.isoformat()}".encode()
        ).hexdigest()[:12]
        
        return LearningPattern(
            pattern_id=pattern_id,
            pattern_type=f"{experience.task_type.value}_pattern",
            conditions=features,
            actions=experience.output_data,
            success_rate=experience.feedback_score,
            usage_count=1,
            last_used=experience.timestamp,
            confidence=experience.feedback_score
        )
    
    def save_pattern(self, pattern: LearningPattern):
        """حفظ نمط تعلم جديد"""
        with sqlite3.connect(self.brain_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO learning_patterns 
                (pattern_id, pattern_type, conditions, actions, success_rate, 
                 usage_count, last_used, confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                pattern.pattern_id,
                pattern.pattern_type,
                json.dumps(pattern.conditions),
                json.dumps(pattern.actions),
                pattern.success_rate,
                pattern.usage_count,
                pattern.last_used.isoformat(),
                pattern.confidence
            ))
        
        self.patterns[pattern.pattern_id] = pattern
        logger.info(f"تم حفظ نمط جديد: {pattern.pattern_id}")
    
    def update_pattern(self, pattern: LearningPattern, experience: Experience):
        """تحديث نمط موجود بناءً على تجربة جديدة"""
        # تحديث معدل النجاح
        old_success = pattern.success_rate * pattern.usage_count
        new_success = old_success + experience.feedback_score
        pattern.usage_count += 1
        pattern.success_rate = new_success / pattern.usage_count
        
        # تحديث الثقة
        pattern.confidence = (pattern.confidence + experience.feedback_score) / 2
        pattern.last_used = experience.timestamp
        
        # حفظ التحديث
        self.save_pattern(pattern)
    
    def get_best_patterns(self, task_type: TaskType, limit: int = 5) -> List[LearningPattern]:
        """الحصول على أفضل الأنماط لنوع مهمة معين"""
        relevant_patterns = [
            pattern for pattern in self.patterns.values()
            if pattern.pattern_type.startswith(task_type.value)
        ]
        
        # ترتيب حسب الثقة ومعدل النجاح
        relevant_patterns.sort(
            key=lambda p: (p.confidence * p.success_rate, p.usage_count),
            reverse=True
        )
        
        return relevant_patterns[:limit]
    
    def save_brain_state(self):
        """حفظ حالة الدماغ الحالية"""
        state = {
            "current_strategy": self.current_strategy.value,
            "learning_phase": self.learning_phase.value,
            "confidence_threshold": self.confidence_threshold,
            "exploration_rate": self.exploration_rate,
            "total_experiences": self.total_experiences,
            "successful_experiences": self.successful_experiences,
            "learning_rate": self.learning_rate,
            "adaptation_speed": self.adaptation_speed
        }
        
        with sqlite3.connect(self.brain_path) as conn:
            for key, value in state.items():
                conn.execute("""
                    INSERT OR REPLACE INTO brain_state (key, value, updated_at)
                    VALUES (?, ?, ?)
                """, (key, json.dumps(value), datetime.now().isoformat()))
    
    def load_brain_state(self):
        """تحميل حالة الدماغ المحفوظة"""
        try:
            with sqlite3.connect(self.brain_path) as conn:
                cursor = conn.execute("SELECT key, value FROM brain_state")
                state_data = cursor.fetchall()
                
                for key, value in state_data:
                    parsed_value = json.loads(value)
                    
                    if key == "current_strategy":
                        self.current_strategy = LearningStrategy(parsed_value)
                    elif key == "learning_phase":
                        self.learning_phase = LearningPhase(parsed_value)
                    elif hasattr(self, key):
                        setattr(self, key, parsed_value)
                
                # تحميل الأنماط
                self.load_patterns()
                
        except Exception as e:
            logger.warning(f"لم يتم العثور على حالة محفوظة أو خطأ في التحميل: {e}")
    
    def load_patterns(self):
        """تحميل الأنماط المحفوظة"""
        try:
            with sqlite3.connect(self.brain_path) as conn:
                cursor = conn.execute("SELECT * FROM learning_patterns")
                patterns_data = cursor.fetchall()
                
                for row in patterns_data:
                    pattern = LearningPattern(
                        pattern_id=row[0],
                        pattern_type=row[1],
                        conditions=json.loads(row[2]),
                        actions=json.loads(row[3]),
                        success_rate=row[4],
                        usage_count=row[5],
                        last_used=datetime.fromisoformat(row[6]),
                        confidence=row[7]
                    )
                    self.patterns[pattern.pattern_id] = pattern
                
                logger.info(f"تم تحميل {len(self.patterns)} نمط تعلم")
                
        except Exception as e:
            logger.warning(f"خطأ في تحميل الأنماط: {e}")

class AISeed:
    """بذرة الذكاء الاصطناعي الرئيسية"""
    
    def __init__(self, seed_id: str = None, orchestrator=None):
        self.seed_id = seed_id or f"seed_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.orchestrator = orchestrator
        self.brain = AISeedBrain(f"ai_seed_brain_{self.seed_id}.db")
        
        # إعدادات التعلم
        self.learning_enabled = True
        self.auto_evaluation = True
        self.external_evaluator = None
        
        # إحصائيات الأداء
        self.performance_metrics = {
            "tasks_completed": 0,
            "average_score": 0.0,
            "improvement_rate": 0.0,
            "learning_efficiency": 0.0
        }
        
        # خيط التعلم المستمر
        self.learning_thread = None
        self.learning_active = False
        
        logger.info(f"تم إنشاء بذرة ذكاء اصطناعي: {self.seed_id}")
    
    def start_learning(self):
        """بدء عملية التعلم المستمر"""
        if self.learning_active:
            return
        
        self.learning_active = True
        self.learning_thread = threading.Thread(target=self._continuous_learning, daemon=True)
        self.learning_thread.start()
        logger.info("تم بدء التعلم المستمر")
    
    def stop_learning(self):
        """إيقاف عملية التعلم المستمر"""
        self.learning_active = False
        if self.learning_thread:
            self.learning_thread.join()
        logger.info("تم إيقاف التعلم المستمر")
    
    def _continuous_learning(self):
        """حلقة التعلم المستمر"""
        while self.learning_active:
            try:
                # تحليل الأداء الحالي
                self.analyze_performance()
                
                # تحديث استراتيجية التعلم
                self.update_learning_strategy()
                
                # تحسين الأنماط الموجودة
                self.optimize_patterns()
                
                # حفظ حالة الدماغ
                self.brain.save_brain_state()
                
                # انتظار قبل الدورة التالية
                time.sleep(60)  # دقيقة واحدة
                
            except Exception as e:
                logger.error(f"خطأ في حلقة التعلم المستمر: {e}")
                time.sleep(30)  # انتظار أقل في حالة الخطأ
    
    def process_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """معالجة مهمة جديدة"""
        try:
            task_type = TaskType(task_data.get("type", "code_generation"))
            
            # اختيار الاستراتيجية المناسبة
            strategy = self.select_strategy(task_type, task_data)
            
            # تنفيذ المهمة
            result = self.execute_task(task_type, task_data, strategy)
            
            # إنشاء تجربة جديدة
            experience = Experience(
                id=f"exp_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                task_type=task_type,
                input_data=task_data,
                output_data=result,
                context={"strategy": strategy.value, "seed_id": self.seed_id},
                feedback_score=0.0,  # سيتم تحديثها لاحقاً
                learning_phase=self.brain.learning_phase
            )
            
            # تقييم النتيجة
            if self.auto_evaluation:
                feedback_score = self.evaluate_result(task_type, task_data, result)
                experience.feedback_score = feedback_score
            
            # حفظ التجربة
            if self.learning_enabled:
                self.brain.save_experience(experience)
            
            # تحديث الإحصائيات
            self.update_performance_metrics(experience)
            
            return {
                "result": result,
                "experience_id": experience.id,
                "confidence": experience.feedback_score,
                "strategy_used": strategy.value,
                "learning_phase": self.brain.learning_phase.value
            }
            
        except Exception as e:
            logger.error(f"خطأ في معالجة المهمة: {e}")
            return {"error": str(e), "result": None}
    
    def select_strategy(self, task_type: TaskType, task_data: Dict[str, Any]) -> LearningStrategy:
        """اختيار استراتيجية التعلم المناسبة"""
        # الحصول على أفضل الأنماط للمهمة
        best_patterns = self.brain.get_best_patterns(task_type)
        
        if not best_patterns:
            return LearningStrategy.EXPLORATION
        
        # تحديد الاستراتيجية بناءً على الثقة والخبرة
        avg_confidence = sum(p.confidence for p in best_patterns) / len(best_patterns)
        
        if avg_confidence > 0.8:
            return LearningStrategy.EXPLOITATION
        elif avg_confidence > 0.6:
            return LearningStrategy.IMITATION
        elif self.brain.total_experiences > 50:
            return LearningStrategy.TRANSFER
        else:
            return LearningStrategy.EXPLORATION
    
    def execute_task(self, task_type: TaskType, task_data: Dict[str, Any], 
                    strategy: LearningStrategy) -> Dict[str, Any]:
        """تنفيذ المهمة باستخدام الاستراتيجية المحددة"""
        
        if strategy == LearningStrategy.IMITATION:
            return self.execute_with_imitation(task_type, task_data)
        elif strategy == LearningStrategy.EXPLOITATION:
            return self.execute_with_exploitation(task_type, task_data)
        elif strategy == LearningStrategy.TRANSFER:
            return self.execute_with_transfer(task_type, task_data)
        else:  # EXPLORATION
            return self.execute_with_exploration(task_type, task_data)
    
    def execute_with_imitation(self, task_type: TaskType, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """تنفيذ بالتقليد - استخدام أفضل الأنماط الموجودة"""
        best_patterns = self.brain.get_best_patterns(task_type, limit=1)
        
        if best_patterns:
            pattern = best_patterns[0]
            # تكييف الحل المحفوظ مع المهمة الحالية
            adapted_result = self.adapt_pattern_to_task(pattern, task_data)
            return adapted_result
        
        # إذا لم توجد أنماط، استخدم الاستكشاف
        return self.execute_with_exploration(task_type, task_data)
    
    def execute_with_exploitation(self, task_type: TaskType, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """تنفيذ بالاستغلال - استخدام أفضل الحلول المعروفة"""
        best_patterns = self.brain.get_best_patterns(task_type, limit=3)
        
        if best_patterns:
            # دمج أفضل الأنماط
            combined_result = self.combine_patterns(best_patterns, task_data)
            return combined_result
        
        return self.execute_with_exploration(task_type, task_data)
    
    def execute_with_transfer(self, task_type: TaskType, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """تنفيذ بنقل المعرفة - استخدام معرفة من مهام مشابهة"""
        # البحث عن أنماط من أنواع مهام مشابهة
        related_patterns = []
        for pattern in self.brain.patterns.values():
            if self.is_related_task_type(task_type, pattern.pattern_type):
                related_patterns.append(pattern)
        
        if related_patterns:
            # تكييف المعرفة المنقولة
            transferred_result = self.transfer_knowledge(related_patterns, task_data)
            return transferred_result
        
        return self.execute_with_exploration(task_type, task_data)
    
    def execute_with_exploration(self, task_type: TaskType, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """تنفيذ بالاستكشاف - توليد حلول جديدة"""
        if self.orchestrator:
            # استخدام المنسق لتوليد حل جديد
            if task_type == TaskType.CODE_GENERATION:
                result = self.orchestrator.generate_code(
                    task=task_data.get("description", ""),
                    language=task_data.get("language", "python")
                )
                return {"code": result, "method": "orchestrator_generation"}
            elif task_type == TaskType.CODE_REVIEW:
                result = self.orchestrator.review_code(
                    code=task_data.get("code", ""),
                    focus_areas=task_data.get("focus_areas", [])
                )
                return {"review": result, "method": "orchestrator_review"}
        
        # حل افتراضي بسيط
        return {
            "result": f"حل استكشافي لمهمة {task_type.value}",
            "method": "basic_exploration",
            "confidence": 0.3
        }
    
    def adapt_pattern_to_task(self, pattern: LearningPattern, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """تكييف نمط موجود مع المهمة الحالية"""
        # نسخ الإجراءات الأساسية من النمط
        adapted_actions = pattern.actions.copy()
        
        # تخصيص الحل للمهمة الحالية
        if "description" in task_data:
            adapted_actions["adapted_for"] = task_data["description"]
        
        adapted_actions["adaptation_confidence"] = pattern.confidence * 0.9
        adapted_actions["method"] = "pattern_adaptation"
        
        return adapted_actions
    
    def combine_patterns(self, patterns: List[LearningPattern], task_data: Dict[str, Any]) -> Dict[str, Any]:
        """دمج عدة أنماط لإنشاء حل محسن"""
        combined_result = {
            "method": "pattern_combination",
            "patterns_used": [p.pattern_id for p in patterns],
            "combined_confidence": sum(p.confidence for p in patterns) / len(patterns)
        }
        
        # دمج الإجراءات من الأنماط المختلفة
        for i, pattern in enumerate(patterns):
            for key, value in pattern.actions.items():
                if key not in combined_result:
                    combined_result[key] = value
                elif isinstance(value, str) and isinstance(combined_result[key], str):
                    combined_result[key] += f"\n# من النمط {i+1}:\n{value}"
        
        return combined_result
    
    def transfer_knowledge(self, related_patterns: List[LearningPattern], task_data: Dict[str, Any]) -> Dict[str, Any]:
        """نقل المعرفة من مهام مشابهة"""
        transferred_result = {
            "method": "knowledge_transfer",
            "source_patterns": [p.pattern_id for p in related_patterns],
            "transfer_confidence": 0.6
        }
        
        # استخراج المبادئ العامة من الأنماط المشابهة
        common_principles = self.extract_common_principles(related_patterns)
        transferred_result.update(common_principles)
        
        return transferred_result
    
    def extract_common_principles(self, patterns: List[LearningPattern]) -> Dict[str, Any]:
        """استخراج المبادئ المشتركة من الأنماط"""
        principles = {}
        
        # تحليل الخصائص المشتركة
        all_conditions = [p.conditions for p in patterns]
        all_actions = [p.actions for p in patterns]
        
        # العثور على القيم المشتركة
        common_keys = set.intersection(*[set(d.keys()) for d in all_conditions])
        
        for key in common_keys:
            values = [d[key] for d in all_conditions if key in d]
            if len(set(values)) == 1:  # قيمة مشتركة
                principles[f"common_{key}"] = values[0]
        
        return principles
    
    def is_related_task_type(self, task_type: TaskType, pattern_type: str) -> bool:
        """تحديد ما إذا كان نوع المهمة مرتبط بنوع النمط"""
        task_relationships = {
            TaskType.CODE_GENERATION: ["code_review", "debugging", "testing"],
            TaskType.CODE_REVIEW: ["code_generation", "debugging", "optimization"],
            TaskType.DEBUGGING: ["code_generation", "code_review", "testing"],
            TaskType.OPTIMIZATION: ["code_generation", "code_review"],
            TaskType.TESTING: ["code_generation", "debugging"],
            TaskType.DOCUMENTATION: ["code_generation", "code_review"]
        }
        
        related_types = task_relationships.get(task_type, [])
        return any(related in pattern_type for related in related_types)
    
    def evaluate_result(self, task_type: TaskType, task_data: Dict[str, Any], 
                       result: Dict[str, Any]) -> float:
        """تقييم نتيجة المهمة"""
        try:
            # تقييم أساسي بناءً على وجود النتيجة
            if not result or "error" in result:
                return 0.1
            
            # تقييم حسب نوع المهمة
            if task_type == TaskType.CODE_GENERATION:
                return self.evaluate_code_generation(task_data, result)
            elif task_type == TaskType.CODE_REVIEW:
                return self.evaluate_code_review(task_data, result)
            else:
                # تقييم عام
                return 0.5 if result.get("result") else 0.2
                
        except Exception as e:
            logger.error(f"خطأ في التقييم: {e}")
            return 0.1
    
    def evaluate_code_generation(self, task_data: Dict[str, Any], result: Dict[str, Any]) -> float:
        """تقييم نتائج توليد الكود"""
        score = 0.0
        
        # فحص وجود الكود
        code = result.get("code", "")
        if not code:
            return 0.1
        
        score += 0.3  # نقاط أساسية لوجود الكود
        
        # فحص جودة الكود
        if "def " in code or "class " in code:
            score += 0.2  # وجود دوال أو فئات
        
        if "import " in code:
            score += 0.1  # استخدام مكتبات
        
        if "#" in code:
            score += 0.1  # وجود تعليقات
        
        # فحص التعقيد المناسب
        lines = code.split("\n")
        if 5 <= len(lines) <= 50:
            score += 0.2  # طول مناسب
        
        # فحص الأخطاء النحوية البسيطة
        try:
            compile(code, '<string>', 'exec')
            score += 0.1  # كود قابل للتنفيذ
        except:
            pass
        
        return min(score, 1.0)
    
    def evaluate_code_review(self, task_data: Dict[str, Any], result: Dict[str, Any]) -> float:
        """تقييم نتائج مراجعة الكود"""
        score = 0.0
        
        review = result.get("review", "")
        if not review:
            return 0.1
        
        score += 0.3  # نقاط أساسية لوجود المراجعة
        
        # فحص شمولية المراجعة
        review_lower = review.lower()
        
        if any(word in review_lower for word in ["good", "excellent", "well"]):
            score += 0.2  # تقييم إيجابي
        
        if any(word in review_lower for word in ["issue", "problem", "improve"]):
            score += 0.2  # تحديد مشاكل
        
        if any(word in review_lower for word in ["suggest", "recommend", "consider"]):
            score += 0.2  # اقتراحات تحسين
        
        if len(review.split()) > 20:
            score += 0.1  # مراجعة مفصلة
        
        return min(score, 1.0)
    
    def update_performance_metrics(self, experience: Experience):
        """تحديث مقاييس الأداء"""
        self.performance_metrics["tasks_completed"] += 1
        
        # تحديث المتوسط
        old_avg = self.performance_metrics["average_score"]
        new_score = experience.feedback_score
        task_count = self.performance_metrics["tasks_completed"]
        
        self.performance_metrics["average_score"] = (
            (old_avg * (task_count - 1) + new_score) / task_count
        )
        
        # حساب معدل التحسن
        if task_count > 10:
            recent_scores = [exp.feedback_score for exp in self.brain.experiences[-10:]]
            older_scores = [exp.feedback_score for exp in self.brain.experiences[-20:-10]]
            
            if older_scores:
                recent_avg = sum(recent_scores) / len(recent_scores)
                older_avg = sum(older_scores) / len(older_scores)
                self.performance_metrics["improvement_rate"] = recent_avg - older_avg
        
        # حساب كفاءة التعلم
        if self.brain.total_experiences > 0:
            self.performance_metrics["learning_efficiency"] = (
                self.brain.successful_experiences / self.brain.total_experiences
            )
    
    def analyze_performance(self):
        """تحليل الأداء الحالي"""
        try:
            # تحليل الاتجاهات
            if len(self.brain.experiences) > 20:
                recent_performance = self.analyze_recent_performance()
                self.adjust_learning_parameters(recent_performance)
            
            # تحديث مرحلة التعلم
            self.update_learning_phase()
            
        except Exception as e:
            logger.error(f"خطأ في تحليل الأداء: {e}")
    
    def analyze_recent_performance(self) -> Dict[str, float]:
        """تحليل الأداء الحديث"""
        recent_experiences = self.brain.experiences[-20:]
        
        return {
            "average_score": sum(exp.feedback_score for exp in recent_experiences) / len(recent_experiences),
            "success_rate": len([exp for exp in recent_experiences if exp.feedback_score > 0.7]) / len(recent_experiences),
            "consistency": 1.0 - np.std([exp.feedback_score for exp in recent_experiences]),
            "learning_speed": self.calculate_learning_speed(recent_experiences)
        }
    
    def calculate_learning_speed(self, experiences: List[Experience]) -> float:
        """حساب سرعة التعلم"""
        if len(experiences) < 10:
            return 0.0
        
        # مقارنة النصف الأول بالنصف الثاني
        mid = len(experiences) // 2
        first_half_avg = sum(exp.feedback_score for exp in experiences[:mid]) / mid
        second_half_avg = sum(exp.feedback_score for exp in experiences[mid:]) / (len(experiences) - mid)
        
        return second_half_avg - first_half_avg
    
    def adjust_learning_parameters(self, performance: Dict[str, float]):
        """تعديل معاملات التعلم بناءً على الأداء"""
        avg_score = performance["average_score"]
        success_rate = performance["success_rate"]
        learning_speed = performance["learning_speed"]
        
        # تعديل معدل الاستكشاف
        if success_rate > 0.8:
            self.brain.exploration_rate = max(0.1, self.brain.exploration_rate - 0.05)
        elif success_rate < 0.5:
            self.brain.exploration_rate = min(0.5, self.brain.exploration_rate + 0.05)
        
        # تعديل عتبة الثقة
        if avg_score > 0.8:
            self.brain.confidence_threshold = min(0.9, self.brain.confidence_threshold + 0.05)
        elif avg_score < 0.5:
            self.brain.confidence_threshold = max(0.5, self.brain.confidence_threshold - 0.05)
        
        # تعديل معدل التعلم
        if learning_speed > 0.1:
            self.brain.learning_rate = min(0.2, self.brain.learning_rate + 0.01)
        elif learning_speed < -0.1:
            self.brain.learning_rate = max(0.05, self.brain.learning_rate - 0.01)
    
    def update_learning_phase(self):
        """تحديث مرحلة التعلم"""
        total_exp = self.brain.total_experiences
        success_rate = self.brain.successful_experiences / max(total_exp, 1)
        avg_confidence = sum(p.confidence for p in self.brain.patterns.values()) / max(len(self.brain.patterns), 1)
        
        if total_exp < 10:
            self.brain.learning_phase = LearningPhase.INITIALIZATION
        elif total_exp < 50 or success_rate < 0.5:
            self.brain.learning_phase = LearningPhase.EXPLORATION
        elif success_rate < 0.7 or avg_confidence < 0.7:
            self.brain.learning_phase = LearningPhase.EXPLOITATION
        elif success_rate < 0.85:
            self.brain.learning_phase = LearningPhase.REFINEMENT
        else:
            self.brain.learning_phase = LearningPhase.MASTERY
    
    def update_learning_strategy(self):
        """تحديث استراتيجية التعلم"""
        if self.brain.learning_phase == LearningPhase.INITIALIZATION:
            self.brain.current_strategy = LearningStrategy.EXPLORATION
        elif self.brain.learning_phase == LearningPhase.EXPLORATION:
            self.brain.current_strategy = LearningStrategy.EXPLORATION
        elif self.brain.learning_phase == LearningPhase.EXPLOITATION:
            self.brain.current_strategy = LearningStrategy.IMITATION
        elif self.brain.learning_phase == LearningPhase.REFINEMENT:
            self.brain.current_strategy = LearningStrategy.REINFORCEMENT
        else:  # MASTERY
            self.brain.current_strategy = LearningStrategy.TRANSFER
    
    def optimize_patterns(self):
        """تحسين الأنماط الموجودة"""
        try:
            # إزالة الأنماط ضعيفة الأداء
            weak_patterns = [
                pattern_id for pattern_id, pattern in self.brain.patterns.items()
                if pattern.confidence < 0.3 and pattern.usage_count < 3
            ]
            
            for pattern_id in weak_patterns:
                del self.brain.patterns[pattern_id]
                logger.info(f"تم حذف نمط ضعيف: {pattern_id}")
            
            # دمج الأنماط المتشابهة
            self.merge_similar_patterns()
            
        except Exception as e:
            logger.error(f"خطأ في تحسين الأنماط: {e}")
    
    def merge_similar_patterns(self):
        """دمج الأنماط المتشابهة"""
        patterns_list = list(self.brain.patterns.values())
        
        for i, pattern1 in enumerate(patterns_list):
            for j, pattern2 in enumerate(patterns_list[i+1:], i+1):
                similarity = self.brain.calculate_similarity(
                    pattern1.conditions, pattern2.conditions
                )
                
                if similarity > 0.9:  # أنماط متشابهة جداً
                    # دمج النمطين
                    merged_pattern = self.merge_two_patterns(pattern1, pattern2)
                    
                    # حذف الأنماط القديمة وإضافة المدموج
                    if pattern1.pattern_id in self.brain.patterns:
                        del self.brain.patterns[pattern1.pattern_id]
                    if pattern2.pattern_id in self.brain.patterns:
                        del self.brain.patterns[pattern2.pattern_id]
                    
                    self.brain.save_pattern(merged_pattern)
                    break
    
    def merge_two_patterns(self, pattern1: LearningPattern, pattern2: LearningPattern) -> LearningPattern:
        """دمج نمطين متشابهين"""
        merged_id = f"merged_{pattern1.pattern_id[:6]}_{pattern2.pattern_id[:6]}"
        
        # دمج الشروط (أخذ المتوسط للقيم الرقمية)
        merged_conditions = pattern1.conditions.copy()
        for key, value in pattern2.conditions.items():
            if key in merged_conditions:
                if isinstance(value, (int, float)) and isinstance(merged_conditions[key], (int, float)):
                    merged_conditions[key] = (merged_conditions[key] + value) / 2
            else:
                merged_conditions[key] = value
        
        # دمج الإجراءات
        merged_actions = pattern1.actions.copy()
        merged_actions.update(pattern2.actions)
        
        # حساب المقاييس المدموجة
        total_usage = pattern1.usage_count + pattern2.usage_count
        merged_success_rate = (
            (pattern1.success_rate * pattern1.usage_count + 
             pattern2.success_rate * pattern2.usage_count) / total_usage
        )
        merged_confidence = (pattern1.confidence + pattern2.confidence) / 2
        
        return LearningPattern(
            pattern_id=merged_id,
            pattern_type=pattern1.pattern_type,
            conditions=merged_conditions,
            actions=merged_actions,
            success_rate=merged_success_rate,
            usage_count=total_usage,
            last_used=max(pattern1.last_used, pattern2.last_used),
            confidence=merged_confidence
        )
    
    def get_status(self) -> Dict[str, Any]:
        """الحصول على حالة البذرة الحالية"""
        return {
            "seed_id": self.seed_id,
            "learning_phase": self.brain.learning_phase.value,
            "current_strategy": self.brain.current_strategy.value,
            "total_experiences": self.brain.total_experiences,
            "successful_experiences": self.brain.successful_experiences,
            "patterns_count": len(self.brain.patterns),
            "performance_metrics": self.performance_metrics,
            "learning_parameters": {
                "exploration_rate": self.brain.exploration_rate,
                "confidence_threshold": self.brain.confidence_threshold,
                "learning_rate": self.brain.learning_rate
            },
            "learning_active": self.learning_active
        }
    
    def export_knowledge(self) -> Dict[str, Any]:
        """تصدير المعرفة المكتسبة"""
        return {
            "seed_id": self.seed_id,
            "export_timestamp": datetime.now().isoformat(),
            "brain_state": {
                "learning_phase": self.brain.learning_phase.value,
                "total_experiences": self.brain.total_experiences,
                "successful_experiences": self.brain.successful_experiences
            },
            "patterns": [asdict(pattern) for pattern in self.brain.patterns.values()],
            "performance_metrics": self.performance_metrics
        }
    
    def import_knowledge(self, knowledge_data: Dict[str, Any]):
        """استيراد معرفة من بذرة أخرى"""
        try:
            # استيراد الأنماط
            for pattern_data in knowledge_data.get("patterns", []):
                pattern = LearningPattern(**pattern_data)
                # تعديل معرف النمط لتجنب التضارب
                pattern.pattern_id = f"imported_{pattern.pattern_id}"
                self.brain.save_pattern(pattern)
            
            logger.info(f"تم استيراد {len(knowledge_data.get('patterns', []))} نمط")
            
        except Exception as e:
            logger.error(f"خطأ في استيراد المعرفة: {e}")

if __name__ == "__main__":
    # مثال على الاستخدام
    seed = AISeed("test_seed")
    
    try:
        # بدء التعلم
        seed.start_learning()
        
        # معالجة مهمة تجريبية
        task_data = {
            "type": "code_generation",
            "description": "إنشاء دالة لحساب المضروب",
            "language": "python"
        }
        
        result = seed.process_task(task_data)
        print(f"نتيجة المهمة: {result}")
        
        # عرض حالة البذرة
        status = seed.get_status()
        print(f"حالة البذرة: {status}")
        
        # تصدير المعرفة
        knowledge = seed.export_knowledge()
        print(f"تم تصدير {len(knowledge['patterns'])} نمط")
        
    except KeyboardInterrupt:
        print("إيقاف البرنامج...")
    finally:
        seed.stop_learning()

