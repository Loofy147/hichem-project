import os
from dotenv import load_dotenv
from openai import OpenAI
from config import Config
from system_integrator import SystemIntegrator

load_dotenv()

class Orchestrator:
    def __init__(self):
        self.client = OpenAI(api_key=Config.OPENAI_API_KEY)
        self.system_integrator = SystemIntegrator(project_root=os.getcwd())
        self.mcp_context = Config.MCP_CONTEXT

    def _load_prompt_template(self, template_name):
        path = os.path.join(Config.PROMPTS_DIR, template_name)
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()

    def _generate_text(self, prompt, model="gpt-4o"):
        response = self.client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": self._load_prompt_template("system_prompt.md")},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content

    def orchestrate_code_generation(self, task_description, language="Python", module_name="generated_module"):
        print(f"Orchestrating code generation for: {task_description}")

        # 1. Generate Initial Code
        code_prompt = f"Generate {language} code for the following task: {task_description}\n\nCode:"
        generated_code = self._generate_text(code_prompt)
        module_file = f"meta-orchestrator/{module_name}.py" # Assuming Python for now
        with open(module_file, 'w', encoding='utf-8') as f:
            f.write(generated_code)
        print(f"Initial code generated and saved to {module_file}")

        # 2. Run Static Analysis
        try:
            self.system_integrator.run_static_analysis(language, module_file)
            print("Static analysis passed.")
        except Exception as e:
            print(f"Static analysis failed: {e}")
            # In a real scenario, you'd feed this back to the LLM for correction

        # 3. Generate Unit Tests
        test_template = self._load_prompt_template("test_prompt.md")
        test_framework = self.mcp_context["test_frameworks"].get(language, "pytest")
        coverage_target = Config.CODE_COVERAGE_TARGET * 100 # Convert to percentage

        test_prompt = test_template.replace("{{phase_name}}", "Test Generation")\
                                   .replace("{{module_name}}", module_name)\
                                   .replace("{{module_file}}", module_file)\
                                   .replace("{{test_framework}}", test_framework)\
                                   .replace("{{coverage_target}}", str(int(coverage_target)))

        generated_tests = self._generate_text(test_prompt)
        test_file = f"meta-orchestrator/test_{module_name}.py"
        with open(test_file, 'w', encoding='utf-8') as f:
            f.write(generated_tests)
        print(f"Unit tests generated and saved to {test_file}")

        # 4. Run Unit Tests
        try:
            self.system_integrator.run_unit_tests(language, test_file)
            print("Unit tests passed.")
        except Exception as e:
            print(f"Unit tests failed: {e}")
            # In a real scenario, you'd feed this back to the LLM for correction

        # 5. Self-Review Loop
        review_template = self._load_prompt_template("review_prompt.md")
        review_prompt = review_template.replace("{{language}}", language)\
                                       .replace("{{generated_code}}", generated_code)

        review_feedback = self._generate_text(review_prompt)
        print("\n--- Self-Review Feedback ---")
        print(review_feedback)
        print("--------------------------")

        # In a more advanced loop, you would parse this feedback and feed it back
        # to the LLM to refine the generated_code, then re-run tests/analysis.
        # For now, we just print the feedback.

        print("Code generation and review process completed.")
        return generated_code, generated_tests, review_feedback

# Example Usage (for testing purposes)
if __name__ == "__main__":
    orchestrator = Orchestrator()
    task = "A Python function that calculates the factorial of a number recursively."
    orchestrator.orchestrate_code_generation(task)



